using Auth0.ManagementApi.Models;
using LBS.Identity.API.ApiClient;
using LBS.Identity.API.Models.Request;
using LBS.Identity.API.Models.Response;
using LBS.Identity.API.Services;
using LBS.Identity.API.Validations;
using Moq;
using Newtonsoft.Json.Linq;

namespace LBS.Identity.Api.UnitTests
{
    public class UserIdentityServiceTests
    {
        private readonly Mock<IIdentityManagementClient> _mockIdentityClient;
        private readonly UserIdentityService _userIdentityService;

        public UserIdentityServiceTests()
        {
            _mockIdentityClient = new Mock<IIdentityManagementClient>();
            _userIdentityService = new UserIdentityService(_mockIdentityClient.Object);
        }

        [Fact]
        public async Task FindUserByLBSNoAsync_ShouldReturnUser_WhenIdIsValid()
        {
            // Arrange
            string lbsNo = "123";
            var expectedUser = new User { Email = "someemail@emailxxxx.com" };

            _mockIdentityClient.Setup(client => client.GetByLBSNoAsync(lbsNo))
                .ReturnsAsync(expectedUser);

            // Act
            var response = await _userIdentityService.FindUserAsync(lbsNo);

            // Assert
            Assert.NotNull(response);
            Assert.Equal(response.Email, "someemail@emailxxxx.com");
        }

        [Fact]
        public async Task FindUserByEmailAsync_ShouldReturnUser_WhenIdIsValid()
        {
            // Arrange
            string userEmail = "someemail@emailxxxx.com";
            var expectedUser = new User { Email = userEmail };

            _mockIdentityClient.Setup(client => client.GetByEmailAsync(userEmail))
                .ReturnsAsync(expectedUser);

            // Act
            var response = await _userIdentityService.FindUserAsync(userEmail);

            // Assert
            Assert.NotNull(response);
            Assert.Equal(userEmail, response.Email);
        }

        [Fact]
        public async Task FindUserByUserIdAsync_ShouldReturnUser_WhenIdIsValid()
        {
            // Arrange
            string userId = Guid.NewGuid().ToString();
            var expectedUser = new User { UserId = userId };

            _mockIdentityClient.Setup(client => client.GetByIdAsync(userId))
                .ReturnsAsync(expectedUser);

            // Act
            var response = await _userIdentityService.FindUserAsync(userId);

            // Assert
            Assert.NotNull(response);
            Assert.Equal(userId, response.UserId);
        }

        [Fact]
        public async Task CreateUserAsync_ShouldReturnCreatedUser_WhenRequestIsValid()
        {
            // Arrange
            var createUserRequest = new CreateUserRequest
            {
                FirstName = "Bob",
                LastName = "Bobber",
                LBSNo = "1234",
                Email = "test@example.com",
                Password = "Testing123456789",
                Origin = "londonedu website"
            };

            var validator = new CreateUserRequestValidator();

            var validationResult = await validator.ValidateAsync(createUserRequest);

            Assert.True(validationResult.IsValid, "Expected CreateUserRequest to be valid.");

            var user = new User
            {
                FirstName = createUserRequest.FirstName,
                LastName = createUserRequest.LastName,
                Email = createUserRequest.Email,
                AppMetadata = new JObject
                {
                    ["origin"] = createUserRequest.Origin,
                    ["lbs_no"] = createUserRequest.LBSNo
                }
            };

            _mockIdentityClient.Setup(client => client.CreateAsync(It.IsAny<UserCreateRequest>()))
                .ReturnsAsync(user);

            // Act
            var response = await _userIdentityService.CreateUserAsync(createUserRequest);

            // Assert

            Assert.NotNull(response);
            Assert.IsType<GetUserResponse>(response);
            Assert.Equal(createUserRequest.FirstName, response.FirstName);
            Assert.Equal(createUserRequest.LastName, response.LastName);
            Assert.Equal(createUserRequest.Email, response.Email);
            Assert.Equal(createUserRequest.LBSNo, response.LBSNo);
            Assert.Equal(createUserRequest.Origin, response.Origin);
        }

        [Fact]
        public async Task UpdateUserEmailAsync_ShouldReturnUpdatedUser_WhenRequestIsValid()
        {
            // Arrange
            var request = new UpdateEmailRequest
            {
                NewEmail = "new@example.com",
                CurrentEmail = "current@example.com"
            };

            var updatedUser = new User
            {
                Email = request.NewEmail
            };

            _mockIdentityClient.Setup(client => client.UpdateEmailAsync(It.IsAny<UserUpdateRequest>(), It.IsAny<UserUpdateRequest>(), It.IsAny<string>()))
                .ReturnsAsync(updatedUser);

            // Act
            var response = await _userIdentityService.UpdateUserEmailAsync(request, "123", "456");

            // Assert
            Assert.NotNull(response);
            Assert.IsType<GetUserResponse>(response);
            Assert.Equal(request.NewEmail, response.Email);
        }

        [Fact]
        public async Task ResendEmailVerificationAsync_ShouldReturnUser_WhenRequestIsValid()
        {
            // Arrange
            var request = new ResendEmailVerificationRequest { Email = "test@example.com" };

            _mockIdentityClient.Setup(client => client.ResendEmailVerificationAsync(It.IsAny<UserUpdateRequest>(), It.IsAny<string>()))
                .ReturnsAsync(new User { Email = request.Email });

            // Act
            var response = await _userIdentityService.ResendEmailVerificationAsync(request, "123");

            // Assert
            Assert.NotNull(response);
            Assert.IsType<GetUserResponse>(response);
            Assert.Equal(request.Email, response.Email);
        }

        [Fact]
        public async Task DeactivateUserAsync_ShouldReturnDeactivatedUser_WhenRequestIsValid()
        {
            // Arrange
            string userId = "123";
            var email = "test@example.com";

            dynamic appMetaData = new JObject();
            appMetaData.is_deactivated = true;

            var deactivatedUser = new User
            {
                UserId = userId,
                AppMetadata = appMetaData
            };

            _mockIdentityClient.Setup(client => client.DeactivateUserAsync(It.IsAny<UserUpdateRequest>(), userId))
                .ReturnsAsync(deactivatedUser);

            // Act
            var response = await _userIdentityService.DeactivateUserAsync(userId, email);

            // Assert
            Assert.NotNull(response);
            Assert.IsType<GetUserResponse>(response);
            Assert.True(response.IsUserDeactivated);
        }
    }
}
