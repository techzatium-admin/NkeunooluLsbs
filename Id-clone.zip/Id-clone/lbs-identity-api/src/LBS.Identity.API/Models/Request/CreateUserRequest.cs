﻿using Newtonsoft.Json;

namespace LBS.Identity.API.Models.Request
{
    public class CreateUserRequest
    {
        /// <summary>
        /// The email address of the user being created.
        /// </summary>
        public required string? Email { get; set; }

        /// <summary>
        /// The password of the user being created.
        /// </summary>
        public required string? Password { get; set; }

        /// <summary>
        /// The first name of the user being created.
        /// </summary>
        public required string? FirstName { get; set; }

        /// <summary>
        /// The last name of the user being created.
        /// </summary>
        public required string? LastName { get; set; }

        /// <summary>
        /// The LBSNo of the user
        /// </summary>
        public string? LBSNo { get; set; }

        /// <summary>
        /// The originating system of the user being created.
        /// </summary>
        public string? Origin { get; set; }
    }

    public class AppMetaData
    {
        [JsonProperty("lbs_no")]
        public string? LBSNo { get; set; }

        [JsonProperty("has_performed_email_change")]
        public bool? IsEmailChange { get; set; }

        [JsonProperty("last_email_changed")]
        public string? LastEmailChanged { get; set; }

        [JsonProperty("is_deactivated")]
        public bool? IsDeactivated { get; set; }

        [JsonProperty("email_changed_at")]
        public DateTime? EmailChangedAt { get; set; }

        [JsonProperty("password_changed_at")]
        public DateTime? PasswordChangedAt { get; set; }

        [JsonProperty("origin")]
        public string? Origin { get; set; }
    }
}
