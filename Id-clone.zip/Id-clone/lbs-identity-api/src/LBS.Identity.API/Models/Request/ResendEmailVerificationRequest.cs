﻿namespace LBS.Identity.API.Models.Request
{
    public class ResendEmailVerificationRequest
    {
        public string? Email { get; set; }
    }
}
