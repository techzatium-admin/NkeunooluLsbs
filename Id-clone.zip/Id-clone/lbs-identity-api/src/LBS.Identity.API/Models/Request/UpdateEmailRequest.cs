﻿namespace LBS.Identity.API.Models.Request
{
    public class UpdateEmailRequest
    {
        public required string NewEmail { get; set; }
        public required string CurrentEmail { get; set; }
    }
}
