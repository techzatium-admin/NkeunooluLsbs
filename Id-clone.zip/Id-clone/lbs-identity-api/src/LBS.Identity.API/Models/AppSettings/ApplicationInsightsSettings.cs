﻿namespace LBS.Identity.API.Models.AppSettings
{
    public class ApplicationInsightsSettings
    {
        public string? ConnectionString { get; set; }
    }
}
