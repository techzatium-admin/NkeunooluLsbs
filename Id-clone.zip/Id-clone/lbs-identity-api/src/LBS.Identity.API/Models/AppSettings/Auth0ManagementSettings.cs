﻿namespace LBS.Identity.API.Models.AppSettings
{
    public class Auth0ManagementSettings
    {
        public string? Domain { get; set; }
        public string? TokenClientId { get; set; }
        public string? TokenClientSecret { get; set; }
        public string? Audience { get; set; }
        public string? GrantType { get; set; }
        public RetryConfiguration Retries { get; set; } = new();
        public CircuitBreakerConfiguration CircuitBreaker { get; set; } = new();
    }

    public class RetryConfiguration
    {
        public int NumberOfRetries { get; set; } = 2;

        public TimeSpan RetryDelay { get; set; } = TimeSpan.FromSeconds(2);
    }

    public class CircuitBreakerConfiguration
    {
        public double FailureThreshold { get; set; } = 0.5;

        public TimeSpan SamplingDuration { get; set; } = TimeSpan.FromSeconds(20);

        public int MinimumThroughput { get; set; } = 2;

        public TimeSpan DurationOfBreak { get; set; } = TimeSpan.FromSeconds(30);
    }
}
