﻿namespace LBS.Identity.API.Models.Response
{
    public class GetUserResponse
    {
        /// <summary>
        /// The LBSNo of the user identity
        /// </summary>
        public string? LBSNo { get; init; }

        /// <summary>
        /// The ID of the user being retrieved.
        /// </summary>
        public string? UserId { get; init; }

        /// <summary>
        /// The email address of the user being retrieved.
        /// </summary>
        public string? Email { get; init; }

        /// <summary>
        /// The first name of the user being retrieved.
        /// </summary>
        public string? FirstName { get; init; }

        /// <summary>
        /// The last name of the user being retrieved.
        /// </summary>
        public string? LastName { get; init; }

        /// <summary>
        /// User is verified or not
        /// </summary>
        public bool? IsEmailVerified { get; init; }

        /// <summary>
        /// the user is deactivated or not
        /// </summary>
        public bool? IsUserDeactivated { get; init; }

        /// <summary>
        /// The originating system of the user
        /// </summary>
        public string? Origin{ get; init; }
    }
}
