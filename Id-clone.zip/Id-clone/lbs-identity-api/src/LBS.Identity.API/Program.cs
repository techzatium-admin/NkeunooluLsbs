using LBS.Identity.API.HealthChecks;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;

var builder = WebApplication.CreateBuilder(args);

// HSTS Security Headers 
builder.Services.AddHsts(options =>
{
    options.Preload = true;
    options.IncludeSubDomains = true;
    options.MaxAge = TimeSpan.FromDays(365);
});

builder.Services.AddHttpContextAccessor();

//Added Correlation Id support in the header.


builder.Services.Configure<ApplicationInsightsSettings>(builder.Configuration.GetSection("ApplicationInsightsSettings"));
var appInsightsSettings = builder.Services.GetSection<ApplicationInsightsSettings>();
var telemetryClient = new TelemetryClient(new TelemetryConfiguration()
{
    ConnectionString = appInsightsSettings.ConnectionString
});

builder.Services.AddHeaderPropagation(options => options.Headers.Add("X-LBS-Correlation-Id"));

//---Add Serilog
builder.Host.UseSerilog((hostingContext, loggerConfiguration) => loggerConfiguration
    .WriteTo.Console(new CompactJsonFormatter())
    .WriteTo.ApplicationInsights(telemetryClient, TelemetryConverter.Traces)
    .MinimumLevel.Information()
    .MinimumLevel.Override("Microsoft", LogEventLevel.Error)
    .MinimumLevel.Override("Microsoft.AspNetCore", LogEventLevel.Error)
    .Enrich.FromLogContext()
    .Enrich.WithCorrelationIdHeader("X-LBS-Correlation-Id")
    .Enrich.WithHttpContextLog());


//Setting up telemetry logging to app insight.
builder.Services
    .AddOpenTelemetry()
    .UseAzureMonitor(x =>
    {
        x.ConnectionString = appInsightsSettings.ConnectionString;
    })
    .ConfigureResource(configureResource =>
    {
        configureResource.Clear();
        configureResource
            .AddService(
                serviceName: AppDomain.CurrentDomain.FriendlyName,
                serviceInstanceId: Environment.MachineName,
                serviceVersion: "v1",
                autoGenerateServiceInstanceId: false)
            .AddAttributes(new List<KeyValuePair<string, object>>
            {
                new("app-version", "1.0"),
                new("custom-region", "uk-south"),
                new("os.description", RuntimeInformation.OSDescription),
                new("deployment.environment", builder.Environment.EnvironmentName.ToLowerInvariant()),
                new("dotnet-framework", RuntimeInformation.FrameworkDescription),
                new("runtime-identifier", RuntimeInformation.RuntimeIdentifier)
            });
    })
    .WithTracing(tracing =>
    {
        tracing.AddHttpClientInstrumentation(options =>
        {
            options.RecordException = true;
            options.FilterHttpRequestMessage = (httpRequestMessage) =>
            {
                var uri = httpRequestMessage.RequestUri;
                if (uri is null || (
                    uri.OriginalString.Contains("https://uksouth-1.in.applicationinsights.azure.com/v2/track")
                    || uri.OriginalString.Contains("https://login.microsoftonline.com/b556776d-8a0f-4dc9-bb5c-b5e28f8e36fe/.well-known/openid-configuration")
                    || uri.OriginalString.Contains("https://login.microsoftonline.com/common/discovery/keys")))
                {
                    return false;
                }
                return true;
            };

        });
    });

builder.Services.AddHealthChecks()
    .AddCheck<IdentityApiHealth>("Identity API Health check");

builder.Services.AddOpenApi();

//Adde support for catching and standardising any unhandles exception to the problem details.
builder.Services.AddProblemDetails(options =>
{
    options.CustomizeProblemDetails = context =>
    {
        context.ProblemDetails.Instance =
            $"{context.HttpContext.Request.Method} {context.HttpContext.Request.Path}";

        context.ProblemDetails.Extensions.TryAdd("requestId", context.HttpContext.TraceIdentifier);

        Activity? activity = context.HttpContext.Features.Get<IHttpActivityFeature>()?.Activity;
        context.ProblemDetails.Extensions.TryAdd("traceId", activity?.Id);
    };
});

//Added token authentication registered in Entra Id.
builder.Services.Configure<AzADAppRegistration>(builder.Configuration.GetSection("AzADAppRegistration"));
var azADAppRegistration = builder.Services.GetSection<AzADAppRegistration>();
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.Authority = Path.Combine(azADAppRegistration.Instance!, azADAppRegistration.TenantId!);
    options.Audience = azADAppRegistration.ClientId; // The Azure AD App Registration's Application ID.
    options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
    {
        ValidateIssuer = true,
    };
});

builder.Services.AddAuthorization();

builder.Services.AddEndpointsApiExplorer();

//Adding API document settings.
builder.Services.AddSwaggerGen(options =>
{
    options.AddSecurityDefinition("AzureAdAuth",
        new()
        {
            Name = "Authorization",
            Description = "Using the Authorization header with the Bearer scheme.",
            Type = SecuritySchemeType.Http,
            Scheme = "Bearer",
            In = ParameterLocation.Header,
            Reference = new OpenApiReference
            {
                Type = ReferenceType.SecurityScheme,
                Id = "AzureAdAuth"
            }
        });
    options.AddSecurityRequirement(new()
    {
        {
            new()
            {
                Reference = new OpenApiReference {
                    Type = ReferenceType.SecurityScheme,
                    Id = "AzureAdAuth"
                }
            }, new List<string>()
        }
    });
    options.SupportNonNullableReferenceTypes();
});

//Fluent validation registration
builder.Services.AddValidatorsFromAssemblyContaining<Program>();

//API services registration.

builder.Services.Configure<Auth0ManagementSettings>(builder.Configuration.GetSection("Auth0Management"));

var auth0ManagementSettings = builder.Services.GetSection<Auth0ManagementSettings>();
builder.Services.AddSingleton(auth0ManagementSettings);

builder.Services.AddSingleton<IManagementApiClient>(new ManagementApiClient("", auth0ManagementSettings.Domain));
builder.Services.AddSingleton<IAuthenticationApiClient>(new AuthenticationApiClient(auth0ManagementSettings.Domain));
builder.Services.AddSingleton<Auth0ManagementApiTokenGenerator>();
builder.Services.AddSingleton<IIdentityManagementClient, IdentityManagementClient>();
builder.Services.AddSingleton<IUserIdentityService, UserIdentityService>();

//Added resiliency support for the http client IdentityTokenGenerator
//Note: That resiliency registration should always happened at the end of the logging and any classes registration.
builder.Services
    .AddHttpClient<Auth0ManagementApiTokenGenerator>(httpClient =>
    {
        httpClient.BaseAddress = new Uri($"https://{auth0ManagementSettings.Domain}/oauth/token");
    })
    .AddResilienceHandler("token-generator-resilience", (pipeline, context) =>
    {
        pipeline
            .AddRetries(auth0ManagementSettings)
            .AddCircuitBreakers(auth0ManagementSettings)
            .AddTimeout(TimeSpan.FromSeconds(30));
    });


//Added resiliency support for the method,
//Use the ResiliencePipelineProvider<string> in DI to get the pipeline by name "identity-resilience" and then wrap the method.
builder.Services.AddResiliencePipeline("identity-resilience", (pipeline, context) =>
{
    pipeline
        .AddRetries(auth0ManagementSettings)
        .AddCircuitBreakers(auth0ManagementSettings)
        .AddTimeout(TimeSpan.FromSeconds(30));
});


var app = builder.Build();

app.MapHealthChecks("/health", new HealthCheckOptions
{
    ResponseWriter = HealthCheckResponseWriter.WriteResponse
});

app.UseAuthentication();
app.UseAuthorization();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseExceptionHandler();

    //Added API documentation tool
    // Swagger uses: https://localhost:*/swagger
    // Scalar uses: https://localhost:*/scalar/v1
    //Open API uses: Https://localhost:*/openapi/v1.json
    app.MapOpenApi();
    app.UseSwagger();
    app.MapScalarApiReference(opt =>
    {
        opt.Title = "Londonedu Identity API";
        opt.Theme = ScalarTheme.Kepler;
        opt.DefaultHttpClient = new(ScalarTarget.Http, ScalarClient.Http11);
    });
    app.UseSwaggerUI();
}
else
{
    app.UseHsts();
}

app.UseHttpsRedirection();

//Added API endpoints Registration.
app.AddUserIdentityEndpoints();
await app.RunAsync();
