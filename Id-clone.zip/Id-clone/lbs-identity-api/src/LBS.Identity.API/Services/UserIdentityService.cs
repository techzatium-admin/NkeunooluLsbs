﻿namespace LBS.Identity.API.Services
{

    public class UserIdentityService(IIdentityManagementClient identityApiClient) : IUserIdentityService
    {
        public async Task<GetUserResponse?> FindUserAsync(string id)
        {

            if (int.TryParse(id, out int value) && value > 0)
            {
                var user = await identityApiClient.GetByLBSNoAsync(id);
                return user.MapFromEntity();
            }
            else if (ValidationExtensions.IsEmail(id))
            {
                var user = await identityApiClient.GetByEmailAsync(id);
                return user.MapFromEntity();
            }
            else
            {
                var user = await identityApiClient.GetByIdAsync(id);
                return user.MapFromEntity();
            }
        }

        public async Task<GetUserResponse?> CreateUserAsync(CreateUserRequest? request)
        {
            if (request is null)
            {
                return null;
            }

            var createUserEntity = request.MapToEntity();
            var user = await identityApiClient.CreateAsync(createUserEntity);

            return user.MapFromEntity();
        }

        public async Task<GetUserResponse?> UpdateUserEmailAsync(UpdateEmailRequest? request, string? lbsNo, string? userId)
        {
            var userUpdateRequest = request.MapToEntity(lbsNo);
            var user = await identityApiClient.UpdateEmailAsync(userUpdateRequest.appMetaDatChange, userUpdateRequest.emailVerifyChange, userId);
            return user.MapFromEntity();
        }

        public async Task<GetUserResponse?> ResendEmailVerificationAsync(ResendEmailVerificationRequest? request, string? userId)
        {
            var userUpdateRequest = request.MapToEntity();
            var user = await identityApiClient.ResendEmailVerificationAsync(userUpdateRequest, userId);
            return user.MapFromEntity();
        }

        public async Task<GetUserResponse?> DeactivateUserAsync(string? userId, string? email)
        {
            var appMetaData = new AppMetaData()
            {
                IsDeactivated = true
            };

            var userUpdateRequest = new UserUpdateRequest()
            {
                Email = email,
                AppMetadata = appMetaData
            };

            var user = await identityApiClient.DeactivateUserAsync(userUpdateRequest, userId);
            return user.MapFromEntity();
        }
    }
}