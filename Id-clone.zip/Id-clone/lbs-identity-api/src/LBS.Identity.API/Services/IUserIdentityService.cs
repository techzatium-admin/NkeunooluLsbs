﻿namespace LBS.Identity.API.Services
{
    public interface IUserIdentityService
    {
        Task<GetUserResponse?> FindUserAsync(string? id);
        Task<GetUserResponse?> CreateUserAsync(CreateUserRequest request);
        Task<GetUserResponse?> UpdateUserEmailAsync(UpdateEmailRequest request, string? lbsNo, string? userId);
        Task<GetUserResponse?> ResendEmailVerificationAsync(ResendEmailVerificationRequest? request, string? userId);
        Task<GetUserResponse?> DeactivateUserAsync(string? userId, string? email);
    }
}
