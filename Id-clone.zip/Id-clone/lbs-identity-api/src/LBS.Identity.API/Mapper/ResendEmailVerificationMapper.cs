﻿namespace LBS.Identity.API.Mapper
{
    public static class ResendEmailVerificationMapper
    {
        public static UserUpdateRequest? MapToEntity(this ResendEmailVerificationRequest? request)
        {
            if (request is null)
                return default;

            return new UserUpdateRequest()
            {
                Email = request.Email,
                VerifyEmail = true
            };
        }
    }
}
