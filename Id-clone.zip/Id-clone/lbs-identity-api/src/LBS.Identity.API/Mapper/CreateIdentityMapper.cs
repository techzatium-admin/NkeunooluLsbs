﻿namespace LBS.Identity.API.Mapper
{
    public static class CreateIdentityMapper
    {
        public static UserCreateRequest? MapToEntity(this CreateUserRequest? request)
        {
            if (request is null)
                return default;

            return new UserCreateRequest
            {
                AppMetadata = new AppMetaData { LBSNo = request.LBSNo, Origin = request.Origin },
                Email = request.Email,
                Password = request.Password,
                FirstName = request.FirstName,
                LastName = request.LastName,
                Connection = "Username-Password-Authentication",
                VerifyEmail = true
            };
        }
    }
}
