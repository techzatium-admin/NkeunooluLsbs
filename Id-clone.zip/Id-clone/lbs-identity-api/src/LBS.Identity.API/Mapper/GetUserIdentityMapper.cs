﻿using Newtonsoft.Json.Linq; // Auth0 ManagementClient package uses Newtonsoft.Json

namespace LBS.Identity.API.Mapper
{
    public static class GetUserIdentityMapper
    {

        public static GetUserResponse? MapFromEntity(this User? user)
        {
            if (user is null)
                return default;

            return new GetUserResponse()
            {
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
                IsEmailVerified = user.EmailVerified,
                UserId = user.UserId,
                LBSNo = GetLBSNo(user),
                IsUserDeactivated = IsUserDeactivated(user),
                Origin = GetOrigin(user)
            };
        }

        private static bool IsUserDeactivated(User user)
        {
            var appMetadata = user.AppMetadata as JObject ?? new JObject();

            return appMetadata["is_deactivated"] != null && appMetadata["is_deactivated"]!.ToObject<bool>();
        }

        private static string? GetLBSNo(User user)
        {
            var appMetadata = user.AppMetadata as JObject ?? new JObject();
            if (appMetadata["lbs_no"] != null)
            {
                return appMetadata["lbs_no"]!.ToObject<string>();
            }

            return null;
        }

        private static string? GetOrigin(User user)
        {
            var appMetadata = user.AppMetadata as JObject ?? new JObject();
            if (appMetadata["origin"] != null)
            {
                return appMetadata["origin"]!.ToObject<string>();
            }

            return null;
        }
    }
}
