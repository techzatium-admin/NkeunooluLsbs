﻿namespace LBS.Identity.API.Mapper
{
    public static class UpdateEmailMapper
    {
        public static (UserUpdateRequest? appMetaDatChange, UserUpdateRequest emailVerifyChange) MapToEntity(this UpdateEmailRequest? request, string? lbsNo)
        {
            if (request is null)
                return default;

            var appmetadaChange = new UserUpdateRequest()
            {
                AppMetadata = new AppMetaData()
                {
                    IsEmailChange = true,
                    LastEmailChanged = request.CurrentEmail,
                    EmailChangedAt = DateTime.Now.ToUniversalTime()
                }
            };

            var emailVerifyChange = new UserUpdateRequest()
            {
                Email = request.NewEmail,
                FullName = request.NewEmail,
                VerifyEmail = true
            };

            return (appmetadaChange, emailVerifyChange);
        }
    }
}
