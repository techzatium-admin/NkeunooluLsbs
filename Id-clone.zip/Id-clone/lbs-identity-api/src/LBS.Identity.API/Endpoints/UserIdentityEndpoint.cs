﻿using Azure;
using Polly.Registry;

namespace LBS.Identity.API.Endpoints
{
    public static class UserIdentityEndpoint
    {
        public static void AddUserIdentityEndpoints(this IEndpointRouteBuilder app)
        {
            var authorizedGroup = app.MapGroup("v1/user")
                .RequireAuthorization()
                .WithTags("Londonedu Identity API")
                .AddEndpointFilter<SecurityHeaderFilter>()
                .AddEndpointFilter(async (efContext, next) =>
                 {
                     var stopwatch = Stopwatch.StartNew();
                     var result = await next(efContext);
                     stopwatch.Stop();
                     var elapsed = stopwatch.ElapsedMilliseconds;
                     var response = efContext.HttpContext.Response;
                     response.Headers.TryAdd("X-Response-Time", $"{elapsed} milliseconds");
                     return result;
                 });

            authorizedGroup.MapGet("/{id}", GetUserAsync)
                .WithName("GetUser")
                .WithSummary("Get user identity details using id")
                .WithDescription("User identity are identified by id as LBSNo, email and User Id");

            authorizedGroup.MapPost("", CreateIdentityAsync)
                .AddEndpointFilter<RequestValidationFilter<CreateUserRequest>>()
                .WithName("CreateUser")
                .WithSummary("Create user Identity")
                .WithDescription("User identity are created and status code 201 is returned as response");

            authorizedGroup.MapPatch("/{id}/email", UpdateUserEmailAsync)
                .AddEndpointFilter<RequestValidationFilter<UpdateEmailRequest>>()
                .WithName("UpdateUserEmail")
                .WithSummary("Update user email")
                .WithDescription("Update User email in user identity record by passing the parameter with current and new email details, after successful update verification email is sent to new updated email for login with new email updated.");

            authorizedGroup.MapPost("/verification-email", ResendUserEmailVerificationAsync)
                .AddEndpointFilter<RequestValidationFilter<ResendEmailVerificationRequest>>()
                .WithName("ResendEmailVerification")
                .WithSummary("Resend email verification for unverified user")
                .WithDescription("Resend email verification again for the unverified user");

            authorizedGroup.MapPost("/{id}/deactivate-user", DeactivateUserAsync)
                .WithName("DeactivateUser")
                .WithSummary("Deactivate User")
                .WithDescription("User identity is deactivated and deactivated flag is set to true.");
        }

        private static async Task<Results<Ok<GetUserResponse>, NotFound<string>, BadRequest<string>>> GetUserAsync(
            string id,
            IUserIdentityService userIdentityService,
            ResiliencePipelineProvider<string> pipelineProvider,
            ILogger<Program> logger,
            CancellationToken cancellationToken)
        {
            if (id is null)
            {
                return TypedResults.BadRequest("Route parameter Id cannot be null");
            }
            var loggingContext = LoggingContext.CreateLoggingContext($"Getting user identity details with id/email/LBSNo {id} from Auth0.");
            try
            {
                var pipeline = pipelineProvider.GetPipeline("identity-resilience");
                logger.LogInformation("Getting user details for user: {Id} from Auth0. {@LoggingContext}", id, loggingContext);
                var user = await pipeline.ExecuteAsync(async ct => await userIdentityService.FindUserAsync(id!));
                logger.LogInformation("Got user Details for user {Id} with result {@User} from Auth0", id, user is null ? "'not found in Auth0'" : user);

                if (user is null)
                {
                    return TypedResults.NotFound("User does not exist");
                }
                return TypedResults.Ok(user);
            }
            catch (ErrorApiException apiEx) when (apiEx.StatusCode == HttpStatusCode.NotFound)
            {
                logger.LogError(apiEx, "User identify with id/email/LBSNo '{Id}' not found in Auth0. {@LoggingContext}", id, loggingContext);
                return TypedResults.NotFound("User does not exist");
            }
            catch (ErrorApiException apiEx)
            {
                logger.LogError(apiEx, "Get User in Auth0 error for user with id/email/LBSNo {Id} {@LoggingContext}", id, loggingContext);
                return TypedResults.BadRequest(apiEx.Message);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Exception when getting User identity from Auth0 for user with id/email/LBSNo {Id} {@LoggingContext}", id, loggingContext);
                return TypedResults.BadRequest(ex.Message);
            }
        }

        private static async Task<Results<CreatedAtRoute<GetUserResponse>, ValidationProblem, Conflict<string>, BadRequest<string>>> CreateIdentityAsync(
            [FromBody] CreateUserRequest request,
            IUserIdentityService userIdentityService,
            ILogger<Program> logger,
            ResiliencePipelineProvider<string> pipelineProvider,
            CancellationToken cancellationToken)
        {
            var loggingContext = LoggingContext.CreateLoggingContext("Create user identity in Auth0.", CreateSafeLoggingRequest(request));
            try
            {
                var pipeline = pipelineProvider.GetPipeline("identity-resilience");
                var getUserResponse = await pipeline.ExecuteAsync(async ct => await userIdentityService.CreateUserAsync(request));

                if (getUserResponse != null)
                {
                    logger.LogInformation("Successfully created user identity {@Response} in Auth0. {@LoggingContext}", getUserResponse, loggingContext);
                }

                return TypedResults.CreatedAtRoute(
                    getUserResponse,
                    "GetUser",
                    new
                    {
                        id = getUserResponse!.UserId
                    });
            }
            catch (ErrorApiException apiEx) when (apiEx.StatusCode == HttpStatusCode.BadRequest && apiEx.Message.Contains("PasswordNoUserInfoError"))
            {
                logger.LogError(apiEx, "User identity password validation error returned from Auth0 for user {Email} {@LoggingContext}", request!.Email, loggingContext);
                return TypedResults.BadRequest("ERROR_PERSONAL_INFO_IN_PASSWORD: " + apiEx.Message);
            }
            catch (ErrorApiException apiEx) when (apiEx.StatusCode == HttpStatusCode.Conflict)
            {
                logger.LogError(apiEx, "User identity already exists in Auth0 for user {Email} {@LoggingContext}", request!.Email, loggingContext);
                return TypedResults.Conflict(apiEx.Message);
            }
            catch (ErrorApiException apiEx)
            {
                logger.LogError(apiEx, "Create User in Auth0 error for user {Email} {@LoggingContext}", request!.Email, loggingContext);
                return TypedResults.BadRequest(apiEx.Message);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Exception when trying to create User identity in Auth0 for user {Email} {@LoggingContext}", request!.Email, loggingContext);
                return TypedResults.BadRequest(ex.Message);
            }
        }

        private async static Task<Results<NoContent, NotFound<string>, Conflict<string>, BadRequest<string>>> UpdateUserEmailAsync(
            string id,
            [FromBody] UpdateEmailRequest request,
            IUserIdentityService userIdentityService,
            ILogger<Program> logger,
            ResiliencePipelineProvider<string> pipelineProvider,
            CancellationToken cancellationToken)
        {
            var loggingContext = LoggingContext.CreateLoggingContext($"Update user identity email for user identity id {id}.", request);
            try
            {
                var pipeline = pipelineProvider.GetPipeline("identity-resilience");
                var getUser = await pipeline.ExecuteAsync(async ct => await userIdentityService.FindUserAsync(id));
                if (getUser is null)
                {
                    logger.LogError("User identity not found with id {Id} in Auth0. {@LoggingContext}", id, loggingContext);
                    return TypedResults.NotFound("User does not exist");
                }

                if (getUser.Email != request.CurrentEmail)
                {
                    logger.LogError("The current user email does not match the email for the user identity found with id {Id}. {@LoggingContext}", id, loggingContext);
                    return TypedResults.NotFound("User did not match with the parameter id and update email request.");
                }

                if (getUser.Email == request.NewEmail)
                {
                    logger.LogError("The new user email is the same as the current email for user identity with id {Id}. {@LoggingContext}", id, loggingContext);
                    return TypedResults.Conflict("Update not possible as current email is same as new email");
                }

                //Check if new user email already exist in the system.
                var getNewUser = await pipeline.ExecuteAsync(async ct => await userIdentityService.FindUserAsync(request.NewEmail));
                if (getNewUser != null)
                {
                    logger.LogError("The new user email already exist in the identity system: {Email}. {@LoggingContext}", request.NewEmail, loggingContext);
                    return TypedResults.Conflict("New email address provided already exist in the identity system");
                }

                //Add resiliency
                var result = await pipeline.ExecuteAsync(async ct => await userIdentityService.UpdateUserEmailAsync(request, getUser.LBSNo, getUser.UserId));
                return TypedResults.NoContent();
            }
            catch (ErrorApiException apiEx) when (apiEx.StatusCode == HttpStatusCode.NotFound)
            {
                logger.LogError(apiEx, "User identity with id {Id} not found in Auth0. {@LoggingContext}", id, loggingContext);
                return TypedResults.NotFound("User does not exist");
            }
            catch (ErrorApiException apiEx)
            {
                logger.LogError(apiEx, "Error when updating the user email for user identity id {Id}. Bad request. {@LoggingContext}", id, loggingContext);
                return TypedResults.BadRequest(apiEx.Message);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Exception when trying to update User identity in Auth0 for user {Id} {@LoggingContext}", id, loggingContext);
                return TypedResults.BadRequest(ex.Message);
            }
        }

        private static async Task<Results<Ok<string>, NotFound<string>, BadRequest<string>>> ResendUserEmailVerificationAsync(
            [FromBody] ResendEmailVerificationRequest request,
            IUserIdentityService userIdentityService,
            ILogger<Program> logger,
            ResiliencePipelineProvider<string> pipelineProvider,
            CancellationToken cancellationToken)
        {
            var loggingContext = LoggingContext.CreateLoggingContext($"Resend user identity email verification.", request);
            try
            {
                var pipeline = pipelineProvider.GetPipeline("identity-resilience");

                var getUser = await pipeline.ExecuteAsync(async ct => await userIdentityService.FindUserAsync(request.Email));
                if (getUser is null)
                {
                    logger.LogWarning("User identity with email {Email} not found in Auth0 to resend verification. {@LoggingContext}", request.Email, loggingContext);
                    return TypedResults.NotFound("User does not exist");
                }

                if (getUser.IsUserDeactivated ?? false)
                {
                    logger.LogWarning("User identity with email {Email} is deactivated. Cannot resend verification. {@LoggingContext}", request.Email, loggingContext);
                    return TypedResults.BadRequest("User is deactivated.");
                }

                if (getUser.IsEmailVerified ?? false)
                {
                    logger.LogWarning("User identity with email {Email} already verified. Nothing to do. {@LoggingContext}", request.Email, loggingContext);
                    return TypedResults.BadRequest("User is already verified.");
                }

                var result = await pipeline.ExecuteAsync(async ct => await userIdentityService.ResendEmailVerificationAsync(request, getUser.UserId));
                return TypedResults.Ok("Resend email verification sent successfully.");
            }
            catch (ErrorApiException apiEx) when (apiEx.StatusCode == HttpStatusCode.NotFound)
            {
                logger.LogError(apiEx, "User identity with email {Email} not found in Auth0 to resend verification. {@LoggingContext}", request.Email, loggingContext);

                return TypedResults.NotFound("User does not exist");
            }
            catch (ErrorApiException apiEx)
            {
                logger.LogError(apiEx, "Unable to resend email verification due to Bad Request for the user with email {Email}. Bad request. {@LoggingContext}", request.Email, loggingContext);

                return TypedResults.BadRequest(apiEx.Message);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error when trying to resend email verification for user with the email {Email} in Auth0. {@LoggingContext}", request.Email, loggingContext);

                return TypedResults.BadRequest(ex.Message);
            }
        }

        private static async Task<Results<Ok<string>, NotFound<string>, BadRequest<string>>> DeactivateUserAsync(
            string id,
            IUserIdentityService userIdentityService,
            ILogger<Program> logger,
            ResiliencePipelineProvider<string> pipelineProvider,
            CancellationToken cancellationToken)
        {
            var loggingContext = LoggingContext.CreateLoggingContext($"Deactivate user identity with Id {id} in Auth0.");

            try
            {
                var pipeline = pipelineProvider.GetPipeline("identity-resilience");

                var getUser = await pipeline.ExecuteAsync(async ct => await userIdentityService.FindUserAsync(id));
                if (getUser is null)
                {
                    logger.LogError("User identity with id {Id} not found in Auth0 to deactivate. {@LoggingContext}", id, loggingContext);
                    return TypedResults.NotFound("User does not exist");
                }

                if (getUser.IsUserDeactivated!.Value)
                {
                    logger.LogError("User identity with id {Id} is already in a deactivated state. {@LoggingContext}", id, loggingContext);
                    return TypedResults.BadRequest("User is already deactivated.");
                }

                var result = pipeline.ExecuteAsync(async ct => await userIdentityService.DeactivateUserAsync(getUser.UserId, getUser.Email));

                logger.LogInformation("Successfully deactivated user identity with id {Id} in Auth0. {@Response} {@LoggingContext}", id, result, loggingContext);
                return TypedResults.Ok("User updated successfully");
            }
            catch (ErrorApiException apiEx) when (apiEx.StatusCode == HttpStatusCode.NotFound)
            {
                logger.LogError(apiEx, "User identity with id {Id} not found in Auth0 to deactivate. {@LoggingContext}", id, loggingContext);
                return TypedResults.NotFound("User does not exist");
            }
            catch (ErrorApiException apiEx)
            {
                logger.LogError(apiEx, "Unable to deactivate User identity with id {Id}. Bad request. {@LoggingContext}", id, loggingContext);
                return TypedResults.BadRequest(apiEx.Message);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error when deactivating user identity with id {Id} in Auth0. {@LoggingContext}", id, loggingContext);
                return TypedResults.BadRequest(ex.Message);
            }
        }

        private static object CreateSafeLoggingRequest(CreateUserRequest request)
        {
            return new
            {
                request.Email,
                Password = "XXXXXXX",
                request.FirstName,
                request.LastName,
                request.LBSNo
            };
        }
    }
}
