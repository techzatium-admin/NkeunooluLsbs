﻿namespace LBS.Identity.API.ApiClient
{
    public interface IIdentityManagementClient
    {
        Task<User?> GetByIdAsync(string? userId);
        Task<User?> GetByEmailAsync(string userEmail);
        Task<User?> GetByLBSNoAsync(string? userId);
        Task<User?> CreateAsync(UserCreateRequest? request);
        Task<User?> UpdateEmailAsync(UserUpdateRequest? appMetaDataChangeRequest, UserUpdateRequest? emailVerifyChangeRequest,  string? userId);
        Task<User?> ResendEmailVerificationAsync(UserUpdateRequest? request, string? userId);
        Task<User?> DeactivateUserAsync(UserUpdateRequest? request, string? userId);
    }
}
