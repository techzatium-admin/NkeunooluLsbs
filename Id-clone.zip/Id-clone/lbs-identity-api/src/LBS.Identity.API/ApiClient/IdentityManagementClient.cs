﻿
namespace LBS.Identity.API.ApiClient
{
    public class IdentityManagementClient(Auth0ManagementApiTokenGenerator tokenGenerator, IManagementApiClient managementApiClient) : IIdentityManagementClient
    {
        public async Task<User?> GetByIdAsync(string? userId)
        {
            var identityClientToken = await tokenGenerator.Generate();
            managementApiClient.UpdateAccessToken(identityClientToken!.AccessToken);
            var user = await managementApiClient.Users.GetAsync(userId);
            return user;
        }

        public async Task<User?> GetByEmailAsync(string userEmail)
        {
            var request = new GetUsersRequest
            {
                Connection = "Username-Password-Authentication",
                Query = $"identities.connection:\"Username-Password-Authentication\" AND email:\"{userEmail}\"", // or use identities.provider:\"auth0\"
                SearchEngine = "v3"
            };

            var identityClientToken = await tokenGenerator.Generate();
            managementApiClient.UpdateAccessToken(identityClientToken!.AccessToken);
            var user = await managementApiClient.Users.GetAllAsync(request);
            return user.SingleOrDefault();
        }

        public async Task<User?> GetByLBSNoAsync(string? lbsNo)
        {
            var request = new GetUsersRequest
            {
                Connection = "Username-Password-Authentication",
                Query = $"identities.connection:\"Username-Password-Authentication\" AND (app_metadata.lbs_no:\"{lbsNo}\" OR user_metadata.lbs_no:\"{lbsNo}\")",
                SearchEngine = "v3"
            };
            var identityClientToken = await tokenGenerator.Generate();
            managementApiClient.UpdateAccessToken(identityClientToken!.AccessToken);
            var user = await managementApiClient.Users.GetAllAsync(request);
            return user.SingleOrDefault();
        }

        public async Task<User?> CreateAsync(UserCreateRequest? request)
        {
            var identityClientToken = await tokenGenerator.Generate();
            managementApiClient.UpdateAccessToken(identityClientToken!.AccessToken);
            var user = await managementApiClient.Users.CreateAsync(request);
            return user;
        }

        public async Task<User?> UpdateEmailAsync(UserUpdateRequest? appMetaDataChangeRequest, UserUpdateRequest? emailVerifyChangeRequest, string? userId)
        {
            //only update the metatdata
            var identityClientToken = await tokenGenerator.Generate();
            managementApiClient.UpdateAccessToken(identityClientToken!.AccessToken);

            var updateUserMetaData = await managementApiClient.Users.UpdateAsync(userId, appMetaDataChangeRequest);
            var updateEmailVerifyData = await managementApiClient.Users.UpdateAsync(userId, emailVerifyChangeRequest);
            return updateEmailVerifyData;
        }

        public async Task<User?> ResendEmailVerificationAsync(UserUpdateRequest? request, string? userId)
        {
            var identityClientToken = await tokenGenerator.Generate();
            managementApiClient.UpdateAccessToken(identityClientToken!.AccessToken);

            var resendEmailUser = await managementApiClient.Users.UpdateAsync(userId, request);
            return resendEmailUser;
        }

        public async Task<User?> DeactivateUserAsync(UserUpdateRequest? request, string? userId)
        {
            var identityClientToken = await tokenGenerator.Generate();
            managementApiClient.UpdateAccessToken(identityClientToken!.AccessToken);

            var deactivatedUser = await managementApiClient.Users.UpdateAsync(userId, request);
            return deactivatedUser;
        }
    }
}
