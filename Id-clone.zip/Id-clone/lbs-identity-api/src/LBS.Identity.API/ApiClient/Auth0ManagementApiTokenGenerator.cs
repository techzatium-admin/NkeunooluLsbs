﻿
namespace LBS.Identity.API.ApiClient
{
    public class Auth0ManagementApiTokenGenerator(Auth0ManagementSettings auth0ManagementSettings, HttpClient httpClient)
    {
        private IdentityTokenResponse? _identityTokenResponse = new();

        public async Task<IdentityTokenResponse?> Generate()
        {
            if (_identityTokenResponse!.IsValid())
            {
                return _identityTokenResponse;
            }

            if (string.IsNullOrEmpty(auth0ManagementSettings.TokenClientId))
            {
                throw new ArgumentNullException(auth0ManagementSettings.TokenClientId);
            }

            if (string.IsNullOrEmpty(auth0ManagementSettings.TokenClientSecret))
            {
                throw new ArgumentNullException(auth0ManagementSettings.TokenClientSecret);
            }

            if (string.IsNullOrEmpty(auth0ManagementSettings.Domain))
            {
                throw new ArgumentNullException(auth0ManagementSettings.Domain);
            }

            if (string.IsNullOrEmpty(auth0ManagementSettings.Audience))
            {
                throw new ArgumentNullException(auth0ManagementSettings.Audience);
            }

            var formData = new List<KeyValuePair<string, string>>
            {
                new("grant_type", auth0ManagementSettings.GrantType!),
                new("client_id", auth0ManagementSettings.TokenClientId!),
                new("client_secret", auth0ManagementSettings.TokenClientSecret!),
                new("audience", auth0ManagementSettings.Audience!)
            };

            var formUrlEncode = new FormUrlEncodedContent(formData);

            var identityResponseMessage = await httpClient.PostAsync("", formUrlEncode);
            if (identityResponseMessage.IsSuccessStatusCode)
            {
                string result = await identityResponseMessage.Content.ReadAsStringAsync();
                var tokenResponse = System.Text.Json.JsonSerializer.Deserialize<IdentityTokenResponse>(result);
                _identityTokenResponse = tokenResponse;
            }

            return _identityTokenResponse;
        }
    }
}
