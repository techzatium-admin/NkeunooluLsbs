﻿using System.Text.Json.Serialization;

namespace LBS.Identity.API.ApiClient
{
    public class IdentityTokenResponse
    {
        [JsonPropertyName("access_token")]
        public string? AccessToken { get; set; }

        [JsonPropertyName("expires_in")]
        public int ExpiresIn { get; set; }
        public string? Scope { get; set; }

        public DateTime TokenIssued { get; } = DateTime.UtcNow;

        public bool IsValid()
        {
            var expiryTime = TokenIssued.AddSeconds(ExpiresIn);
            return DateTime.UtcNow <= expiryTime;
        }
    }
}
