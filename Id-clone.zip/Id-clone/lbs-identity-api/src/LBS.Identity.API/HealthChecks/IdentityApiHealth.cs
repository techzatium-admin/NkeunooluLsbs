﻿using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace LBS.Identity.API.HealthChecks
{
    public class IdentityApiHealth : IHealthCheck
    {
        public async Task<HealthCheckResult> CheckHealthAsync(
            HealthCheckContext context,
            CancellationToken cancellationToken = default)
        {
            try
            {
                var build = Environment.GetEnvironmentVariable("BUILD_BUILDNUMBER") ?? "unknown";

                var data = new Dictionary<string, object>
            {
                { "build", build }
            };

                return await Task.FromResult(
                    HealthCheckResult.Healthy("Identity API is healthy", data));
            }
            catch (Exception ex)
            {
                return await Task.FromResult(
                    new HealthCheckResult(
                        context.Registration.FailureStatus, "Identity API is unhealthy", ex));
            }
        }
    }
}
