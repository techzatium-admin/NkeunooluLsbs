﻿namespace LBS.Identity.API.Validations
{
    public class UpdateEmailRequestValidator : AbstractValidator<UpdateEmailRequest>
    {
        public UpdateEmailRequestValidator()
        {
            RuleFor(model => model.NewEmail).NotEmpty().EmailAddress().WithErrorCode("InvalidNewEmail");
            RuleFor(model => model.CurrentEmail).NotEmpty().EmailAddress().WithErrorCode("InvalidCurrentEmail");
        }
    }
}
