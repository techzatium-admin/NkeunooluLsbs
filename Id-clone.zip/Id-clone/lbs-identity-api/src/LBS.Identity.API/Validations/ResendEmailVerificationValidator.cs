﻿namespace LBS.Identity.API.Validations
{
    public class ResendEmailVerificationValidator : AbstractValidator<ResendEmailVerificationRequest>
    {
        public ResendEmailVerificationValidator()
        {
            RuleFor(model => model.Email).NotEmpty().EmailAddress().WithErrorCode("InvalidEmail");
        }
    }
}
