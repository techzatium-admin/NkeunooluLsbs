﻿namespace LBS.Identity.API.Validations
{
    public class CreateUserRequestValidator : AbstractValidator<CreateUserRequest>
    {
        public CreateUserRequestValidator()
        {
            RuleFor(model => model.LBSNo)
                .NotEmpty().WithErrorCode("InvalidLBSNo")
                .Custom((x, context) =>
                {
                    if (!int.TryParse(x, out int value) || value < 0)
                    {
                        context.AddFailure($"{x} is not a valid integer or less than 0");
                    }
                });
            RuleFor(model => model.FirstName).NotEmpty().WithErrorCode("InvalidFirstName");
            RuleFor(model => model.LastName).NotEmpty().WithErrorCode("InvalidLastName");
            RuleFor(model => model.Email).NotEmpty().EmailAddress().WithErrorCode("InvalidEmail");
            RuleFor(model => model.Password).NotEmpty().WithErrorCode("InvalidPassword");
            RuleFor(model => model.Origin).NotEmpty().WithErrorCode("NoOrigin");
        }
    }
}
