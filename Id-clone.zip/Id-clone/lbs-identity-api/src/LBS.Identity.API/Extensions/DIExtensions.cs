﻿namespace LBS.Identity.API.IdentityExtensions
{
    public static class DIExtensions
    {
        public static T GetSection<T>(this IServiceCollection services) where T : class, new()
        {
            using (var scope = services.BuildServiceProvider())
            {
                return scope.GetRequiredService<IOptions<T>>().Value;
            }
        }

        public static LoggerConfiguration WithHttpContextLog(this LoggerEnrichmentConfiguration enrichmentConfiguration)
        {
            if (enrichmentConfiguration == null) throw new ArgumentNullException(nameof(enrichmentConfiguration));
            return enrichmentConfiguration.With<HttpContextLogEnricher>();
        }
    }
}
