﻿using Azure;
using Polly;
using Polly.Timeout;
using System.Net.Sockets;

namespace LBS.Identity.API.Extensions
{
    public static class ResiliencyExtensions
    {
        private static ValueTask<bool> HandleHttpError(Outcome<HttpResponseMessage> outcome) => outcome switch
        {
            { Exception: RateLimitApiException } => PredicateResult.True(),
            { Exception: SocketException } => PredicateResult.True(),
            { Exception: TimeoutException } => PredicateResult.True(),
            { Result.StatusCode: HttpStatusCode.RequestTimeout } => PredicateResult.True(),
            { Result.StatusCode: HttpStatusCode.TooManyRequests } => PredicateResult.True(),
            { Result.StatusCode: >= HttpStatusCode.InternalServerError } => PredicateResult.True(),
            _ => PredicateResult.False()
        };

        public static ResiliencePipelineBuilder<HttpResponseMessage> AddRetries(this ResiliencePipelineBuilder<HttpResponseMessage> builder, Auth0ManagementSettings? config)
        {
            return builder
                .AddRetry(new RetryStrategyOptions<HttpResponseMessage>()
                {
                    ShouldHandle = args => HandleHttpError(args.Outcome),
                    MaxRetryAttempts = config!.Retries.NumberOfRetries,
                    Delay = config.Retries.RetryDelay,
                    BackoffType = DelayBackoffType.Exponential,
                    UseJitter = true,
                    OnRetry = (args) =>
                    {
                        Console.WriteLine($"Retry Attempt Number : {args.AttemptNumber} after {args.RetryDelay.TotalSeconds} seconds.");
                        return default;
                    }
                });
        }

        public static ResiliencePipelineBuilder<HttpResponseMessage> AddCircuitBreakers(this ResiliencePipelineBuilder<HttpResponseMessage> builder, Auth0ManagementSettings? config)
        {
            return builder
                .AddCircuitBreaker(new CircuitBreakerStrategyOptions<HttpResponseMessage>
                {
                    ShouldHandle = args => HandleHttpError(args.Outcome),
                    MinimumThroughput = config!.CircuitBreaker.MinimumThroughput,
                    BreakDuration = config.CircuitBreaker.DurationOfBreak,
                    FailureRatio = config.CircuitBreaker.FailureThreshold,
                    SamplingDuration = config.CircuitBreaker.SamplingDuration,
                    OnClosed = args =>
                    {
                        //var logger = context.ServiceProvider.GetService<Microsoft.Extensions.Logging.ILogger>();
                        Console.WriteLine("Circuit is closed");
                        return default;
                    },
                    OnOpened = args =>
                    {
                        Console.WriteLine("Circuit is Open");
                        return default;
                    }

                });
        }

        public static ResiliencePipelineBuilder AddRetries(this ResiliencePipelineBuilder builder, Auth0ManagementSettings? config)
        {
            return builder
                .AddRetry(new RetryStrategyOptions
                {
                    ShouldHandle = new PredicateBuilder()
                        .Handle<TimeoutRejectedException>()
                        .Handle<TimeoutException>()
                        .Handle<SocketException>()
                        .Handle<RateLimitApiException>()
                        .Handle<ErrorApiException>(apiEx =>
                        {
                            return RetryStatusCodes.Contains(apiEx.StatusCode);
                        }),
                    Delay = config!.Retries.RetryDelay,
                    MaxRetryAttempts = config!.Retries.NumberOfRetries,
                    BackoffType = DelayBackoffType.Exponential,
                    UseJitter = true,
                    OnRetry = (args) =>
                    {
                        Console.WriteLine($"Retry Attempt Number : {args.AttemptNumber} after {args.RetryDelay.TotalSeconds} seconds.");
                        return default;
                    }
                });
        }

        public static ResiliencePipelineBuilder AddCircuitBreakers(this ResiliencePipelineBuilder builder, Auth0ManagementSettings? config)
        {
            return builder
                .AddCircuitBreaker(new CircuitBreakerStrategyOptions
                {
                    MinimumThroughput = config!.CircuitBreaker.MinimumThroughput,
                    BreakDuration = config.CircuitBreaker.DurationOfBreak,
                    FailureRatio = config.CircuitBreaker.FailureThreshold,
                    SamplingDuration = config.CircuitBreaker.SamplingDuration,
                    ShouldHandle = new PredicateBuilder()
                        .Handle<TimeoutRejectedException>()
                        .Handle<TimeoutException>()
                        .Handle<SocketException>()
                        .Handle<RateLimitApiException>()
                        .Handle<ErrorApiException>(apiEx =>
                        {
                            return RetryStatusCodes.Contains(apiEx.StatusCode);
                        }),
                    OnClosed = args =>
                    {
                        //var logger = context.ServiceProvider.GetService<Microsoft.Extensions.Logging.ILogger>();
                        Console.WriteLine("Circuit is closed");
                        return default;
                    },
                    OnOpened = args =>
                    {
                        Console.WriteLine("Circuit is Open");
                        return default;
                    }

                });
        }

        private static HashSet<HttpStatusCode> RetryStatusCodes => new HashSet<HttpStatusCode>()
        {
            HttpStatusCode.RequestTimeout, //408
            HttpStatusCode.InternalServerError, //500
            HttpStatusCode.BadGateway, //502
            HttpStatusCode.ServiceUnavailable, //503
            HttpStatusCode.GatewayTimeout, //504
            HttpStatusCode.TooManyRequests, //429
        };
    }
}
