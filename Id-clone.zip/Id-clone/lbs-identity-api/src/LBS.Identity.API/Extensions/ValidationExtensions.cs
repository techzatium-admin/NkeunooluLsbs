﻿namespace LBS.Identity.API.IdentityExtensions
{
    public class ValidationExtensions
    {
        public static bool IsEmail(string? input)
        {
            var emailRegex = new System.Text.RegularExpressions.Regex(@"^[^@\s]+@[^@\s]+\.[^@\s]+$");
            return !string.IsNullOrWhiteSpace(input) && emailRegex.IsMatch(input!);
        }

        public static bool IsUserId(string? input)
        {
            var userIdRegex = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z0-9\-]+$");
            return userIdRegex.IsMatch(input!);
        }

        public static bool IsLBSNo(string? input)
        {
            if (!int.TryParse(input, out int value) || value < 0)
            {
                return false;
            }
            return true;
        }
    }
}
