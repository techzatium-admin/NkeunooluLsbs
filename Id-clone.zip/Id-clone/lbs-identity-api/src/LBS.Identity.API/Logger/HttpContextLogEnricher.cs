﻿namespace LBS.Identity.API.Logger
{
    public class HttpContextLogEnricher : ILogEventEnricher
    {
        private readonly IHttpContextAccessor _contextAccessor;

        public HttpContextLogEnricher() : this(new HttpContextAccessor())
        {
        }
        public HttpContextLogEnricher(IHttpContextAccessor httpContextAccessor)
        {
            _contextAccessor = httpContextAccessor;
        }

        public void Enrich(LogEvent logEvent, ILogEventPropertyFactory propertyFactory)
        {
            // Get HttpContext properties here
            var httpContext = _contextAccessor.HttpContext;

            if (httpContext != null)
            {
                //// Add properties to the log event based on HttpContext
                logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("RequestMethod", httpContext.Request.Method));
                logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("UserAgent", httpContext.Request.Headers["User-Agent"]));
                logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("ClientIp", GetIpAddress()));
            }
        }
        private string? GetIpAddress(string forwardHeaderKey = "X-Forwarded-For")
        {
            var ipAddress = _contextAccessor.HttpContext?.Request?.Headers[forwardHeaderKey].FirstOrDefault();

            return !string.IsNullOrEmpty(ipAddress)
                ? GetIpAddressFromProxy(ipAddress)
                : _contextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString();
        }

        private string? GetIpAddressFromProxy(string proxifiedIpList)
        {
            var addresses = proxifiedIpList.Split(',');

            return addresses.Length == 0 ? string.Empty : addresses[0].Trim();
        }
    }
}

