﻿using System.Runtime.CompilerServices;

namespace LBS.Identity.API.Logger
{
    public class LoggingContext
    {
        public string? Message { get; }
        public string MethodName { get; }
        public object? Data { get; }
        public string ServiceName { get; }

        protected LoggingContext(string message, object? data = null, string methodName = "")
        {
            Message = message;
            Data = data;
            MethodName = methodName;
            ServiceName = "Londonedu Identity Api";
        }

        public static LoggingContext CreateLoggingContext(string message, object? data = null, [CallerMemberName] string callerMemberName = "")
        {
            return new(message, data, callerMemberName);
        }
    }
}