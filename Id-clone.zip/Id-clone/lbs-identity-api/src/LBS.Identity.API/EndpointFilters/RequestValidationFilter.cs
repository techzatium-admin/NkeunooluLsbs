﻿namespace LBS.Identity.API.EndpointFilters
{
    public class RequestValidationFilter<T>(IValidator<T> validator) : IEndpointFilter where T : class
    {
        public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
        {
            var model = context.Arguments.FirstOrDefault(arg => arg is T) as T;

            if (model is null)
            {
                return TypedResults.BadRequest("Invalid request body or model is null.");
            }

            var validationResult = await validator.ValidateAsync(model);

            if (!validationResult.IsValid)
            {
                return TypedResults.ValidationProblem(validationResult.ToDictionary());
            }
            return await next(context);
        }
    }
}
