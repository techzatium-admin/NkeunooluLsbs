﻿namespace LBS.Identity.API.EndpointFilters
{
    public class SecurityHeaderFilter : IEndpointFilter
    {
        public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext filterContext, EndpointFilterDelegate next)
        {
            var httpContext = filterContext.HttpContext;
            httpContext.Response.OnStarting(state => {
                httpContext.Response.Headers.TryAdd("Permissions-Policy", new StringValues("accelerometer=(), camera=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), payment=(), usb=()"));
                httpContext.Response.Headers.TryAdd("X-Content-Type-Options", new StringValues("nosniff"));
                httpContext.Response.Headers.TryAdd("X-Frame-Options", new StringValues("DENY"));
                httpContext.Response.Headers.TryAdd("Referrer-Policy", new StringValues("strict-origin-when-cross-origin"));
                httpContext.Response.Headers.TryAdd("X-Permitted-Cross-Domain-Policies", new StringValues("none"));
                httpContext.Response.Headers.TryAdd("x-xss-protection", new StringValues("1; mode=block"));
                httpContext.Response.Headers.TryAdd("Content-Security-Policy", new StringValues("default-src 'none';frame-ancestors 'none';frame-ancestors 'none';upgrade-insecure-requests;block-all-mixed-content;"));
                return Task.CompletedTask;
            }, filterContext);

            return await next(filterContext);
        }
    }
}
