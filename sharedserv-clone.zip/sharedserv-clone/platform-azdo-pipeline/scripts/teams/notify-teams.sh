#!/bin/bash

# Create variable for Microsoft Teams Webhook URL.
webhookURL="https://londonbusinessschool1000.webhook.office.com/webhookb2/0f03220f-79a8-4408-b27d-cf74fb445587@b556776d-8a0f-4dc9-bb5c-b5e28f8e36fe/IncomingWebhook/ae84c430b2e742c0a6d680b3fbfe2714/6b8cd98d-9c2f-4c2d-96d8-7e8ec9c44a09"

# Store variables in positional parameters.
System_TeamProject="$1"
Build_Repository_Name="$2"
Build_SourceBranchName="$3"
Build_DefinitionName="$4"
Agent_JobName="$5"
Agent_JobStatus="$6"
Build_RequestedFor="$7"
Build_SourceVersionMessage="$8"

# Confirm arguments are being passed in as expected. 
echo "Project Name = $System_TeamProject"
echo "Repository Name = $Build_Repository_Name"
echo "Branch Name = $Build_SourceBranchName"
echo "Pipeline Name = $Build_DefinitionName"
echo "Job Name = $Agent_JobName"
echo "Job Status = $Agent_JobStatus"
echo "Requested For = $Build_RequestedFor"
echo "Commit Message = $Build_SourceVersionMessage"

# Print all executed commands to the terminal (used for debugging)
set -x

# Assign write permissions for everyone on file below.
umask 0002

# Create message to post to MS Teams channel.
cat > ./post.json <<endmsg
    {
    "summary": "Summary Here",
    "text": "Project Name: $System_TeamProject \n\n Repository Name: $Build_Repository_Name \n\n Branch Name: $Build_SourceBranchName \n\n Pipeline Name: $Build_DefinitionName \n\n Job Name: $Agent_JobName \n\n Job Status: $Agent_JobStatus \n\n Requested For: $Build_RequestedFor \n\n Commit Message: $Build_SourceVersionMessage"
    }
endmsg

# Post message to MS Teams channel.
curl -H "Content-Type: application/json" -d @post.json $webhookURL -v