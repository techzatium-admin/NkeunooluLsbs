param(
    [Parameter(Mandatory = $true)]
    [string]
    $personalAccessToken,

    [Parameter(Mandatory = $true)]
    [string]
    $organization,

    [Parameter(Mandatory = $true)]
    [string]
    $project,

    [Parameter(Mandatory = $true)]
    [string]
    $variableGroupName,

    [Parameter(Mandatory = $false)]
    [string]
    $variableNamePrefix = "",

    [Parameter(Mandatory = $true, ParameterSetName = 'Terraform')]
    [string]
    $terraformOutputs,

    [Parameter(Mandatory = $true, ParameterSetName = 'ARM')]
    [string]
    $armOutputs,

    [Parameter(Mandatory = $true, ParameterSetName = 'ARM')]
    [string]
    $outputMapFile,

    [Parameter(Mandatory = $true, ParameterSetName = 'ARM')]
    [string]
    $outputMapName,

    [Parameter(Mandatory = $false)]
    [switch]
    $createOutputVariablesOnly = $false
)

$variableGroupName = $variableGroupName.ToLower()

Write-Host ("`nUpdating Variable group: {0}" -f $variableGroupName)

If ($PSCmdlet.ParameterSetName -eq "ARM") {

    $map =  (Get-Content -Path $outputMapFile | ConvertFrom-Json).maps | Where-Object {$_.name -eq $outputMapName}

    Write-Host "`nProcessing ARM outputs"

    $outputs = ($armOutputs | ConvertFrom-Json)
    $outputVariables = New-Object -TypeName PSCustomObject

    Foreach ($output in $outputs.PSObject.Properties) {

        If ($map.variables -contains $output.Name) {

            Switch ($output.Value.type) {
            
                "SecureString" {

                    $isSecret = $true
                }

                default {

                    $isSecret = $false
                }

            }
        
            $outputVariables | Add-Member -NotePropertyName ("{0}{1}" -f $variableNamePrefix.ToLower(), $output.Name.ToUpper()) -NotePropertyValue ([PSCustomObject]@{
                value    = $output.Value.Value
                isSecret = $isSecret
            })
        }
    }

} ElseIf ($PSCmdlet.ParameterSetName -eq "Terraform") {

    Write-Host "`nProcessing Terraform outputs"
    
    $outputs = ConvertFrom-Json (Get-Content -Raw -Path $terraformOutputs)
    $outputVariables = New-Object -TypeName PSCustomObject

    Foreach ($output in $outputs.PSObject.Properties) {

        $variableName = $output.name
        $variableValue = $output.value.value

        Write-Host ("Variable Name: {0}" -f $variableName)
        Write-Host ("##vso[task.setvariable variable=$($variableName);isOutput=true]$variableValue")


        Switch ($output.Value.sensitive) {
            
            true {

                $isSecret = $true
            }

            default {

                $isSecret = $false
            }

        }
        
        $outputVariables | Add-Member -NotePropertyName ("{0}{1}" -f $variableNamePrefix.ToLower(), $variableName.ToUpper()) -NotePropertyValue ([PSCustomObject]@{
            value    = $variableValue
            isSecret = $isSecret
        })
    }

}

If (-not $createOutputVariablesOnly) {

    $variableGroupBaseUrl = ("https://dev.azure.com/{0}/{1}/_apis/distributedtask/variablegroups" -f $organization, $project)
    $variableGroupApiVersion = "api-version=5.1-preview.1"

    $token = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes(":$($personalAccessToken)"))
    $headers = @{Authorization = ("Basic {0}" -f $token) }

    $variableGroupGetUri = ("{0}?{1}&groupName={2}" -f $variableGroupBaseUrl, $variableGroupApiVersion, $variableGroupName)
    $variableGroupGetResponse = Invoke-RestMethod -Uri $variableGroupGetUri -Method Get -Headers $headers


    If ($variableGroupGetResponse.count -eq "0") {

        Write-Host ("ACTION: Create Variable Group '{0}'" -f $variableGroupName)

        $variableGroupContent = @{

            name        = ("{0}" -f $variableGroupName)
            description = ("Variables scoped to: {0}" -f $variableGroupName)
            type        = "Vsts"
            variables   = $outputVariables

        } | ConvertTo-Json

        Invoke-RestMethod -Uri ("{0}?{1}" -f $variableGroupBaseUrl, $variableGroupApiVersion) -Method Post -ContentType "application/json" -Headers $headers -Body ([System.Text.Encoding]::UTF8.GetBytes($variableGroupContent))

    } Else {
    
        Write-Host ("ACTION: Update Variable Group '{0}'" -f $variableGroupName)

        $variableGroup = $variableGroupGetResponse.value[0]
        $variableGroupId = $variableGroup.id
        $variables = $variableGroup.variables

        Foreach ($outputVariable in $outputVariables.PSObject.Properties) {

            $key = $outputVariable.Name

            If ($variables.PSObject.Properties.Name -contains $outputVariable.Name) {

                $variables.$key = $outputVariable.value


            } Else {

                $variables | Add-Member -NotePropertyName $key -NotePropertyValue $outputVariable.value

            }
        }

        $variableGroupContent = $variableGroup | Select-Object -Property id, type, name, variables, description | ConvertTo-Json

        $variableGroupUpdateUri = ("{0}/{1}?{2}" -f $variableGroupBaseUrl, $variableGroupId, $variableGroupApiVersion)
        Invoke-RestMethod -Uri $variableGroupUpdateUri -Method Put -ContentType "application/json" -Headers $headers -Body ([System.Text.Encoding]::UTF8.GetBytes($variableGroupContent))
    }
}
