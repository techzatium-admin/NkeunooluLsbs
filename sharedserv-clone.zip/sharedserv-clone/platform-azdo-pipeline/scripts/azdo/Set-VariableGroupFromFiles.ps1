param(
    [Parameter(Mandatory = $true)]
    [string]
    $personalAccessToken,

    [Parameter(Mandatory = $true)]
    [string]
    $organization,

    [Parameter(Mandatory = $true)]
    [string]
    $project,

    [Parameter(Mandatory = $true)]
    [string]
    $dataDirectory
)

$variableGroupBaseUrl = ("https://dev.azure.com/{0}/{1}/_apis/distributedtask/variablegroups" -f $organization, $project)
$variableGroupApiVersion = "api-version=5.1-preview.1"

$token = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes(":$($personalAccessToken)"))
$headers = @{Authorization = ("Basic {0}" -f $token) }

$files = $dataDirectory | Get-ChildItem -Recurse -File -Filter *.json*

Foreach ($file in $files) {

    Write-Host ("`nProcessing file: {0}" -f $file)
    $variableGroupContent = $file | Get-Content -Raw -Encoding UTF8
    $variableGroupName = ($variableGroupContent | ConvertFrom-Json).name

    $variableGroupGetUri = ("{0}?{1}&groupName={2}" -f $variableGroupBaseUrl, $variableGroupApiVersion, $variableGroupName)
    $variableGroupGetResponse = Invoke-RestMethod -Uri $variableGroupGetUri -Method Get -Headers $headers

    If ($variableGroupGetResponse.count) {

        Write-Host "ACTION: Update"
        $variableGroupId = $variableGroupGetResponse.value[0].id
        $variableGroupUpdateUri = ("{0}/{1}?{2}" -f $variableGroupBaseUrl, $variableGroupId, $variableGroupApiVersion)
        Invoke-RestMethod -Uri $variableGroupUpdateUri -Method Put -ContentType "application/json" -Headers $headers -Body ([System.Text.Encoding]::UTF8.GetBytes($variableGroupContent))

    }
    Else {
        
        Write-Host "ACTION: Create"
        Invoke-RestMethod -Uri ("{0}?{1}" -f $variableGroupBaseUrl, $variableGroupApiVersion) -Method Post -ContentType "application/json" -Headers $headers -Body ([System.Text.Encoding]::UTF8.GetBytes($variableGroupContent))
    }
}
