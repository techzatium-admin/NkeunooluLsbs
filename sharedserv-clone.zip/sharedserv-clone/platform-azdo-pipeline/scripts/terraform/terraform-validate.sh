#!/bin/bash

set -euo pipefail

touch ~/.gitconfig

terraform init -backend=false
terraform validate
rm -r .terraform
