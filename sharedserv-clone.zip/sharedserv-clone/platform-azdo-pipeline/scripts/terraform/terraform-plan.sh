#!/bin/bash
set -eo pipefail

# Command line args
terraform_var_files=${1}

if [ -n "$terraform_var_files" ]
  then
    terraform_var_files=($terraform_var_files)
    terraform_var_files=("${terraform_var_files[@]/#/-var-file=}")
fi

terraform plan ${terraform_var_files[@]}
