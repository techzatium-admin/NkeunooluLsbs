#!/bin/bash
set -euo pipefail

# Command line args
terraform_state_workspace=${1}

terraform workspace select ${terraform_state_workspace} || terraform workspace new ${terraform_state_workspace}
