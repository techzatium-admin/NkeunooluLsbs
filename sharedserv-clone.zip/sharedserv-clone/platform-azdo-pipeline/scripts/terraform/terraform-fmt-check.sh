#!/bin/bash

# Runs a Terraform format check

set -eou pipefail

terraform fmt -diff -check -recursive
