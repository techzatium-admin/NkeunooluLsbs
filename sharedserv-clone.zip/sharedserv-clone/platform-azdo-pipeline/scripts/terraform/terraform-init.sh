#!/bin/bash
set -euo pipefail

# Command line args
terraform_state_resource_group=${1}
terraform_state_storage_account=${2}
terraform_state_container=${3}
terraform_state_key=${4}

pwd
terraform version

terraform init \
  -backend-config="resource_group_name=${terraform_state_resource_group}" \
  -backend-config="storage_account_name=${terraform_state_storage_account}" \
  -backend-config="container_name=${terraform_state_container}" \
  -backend-config="key=${terraform_state_key}"
