# platform-azdo-pipeline

This repository contains pipeline templates and scripts to build, test and deploy infrastructure and code

| Pipeline Name          | Deployment Status |
| ---------------------- | ----------------- |
| build-platform-azdo-pipeline      | [![Build Status](https://dev.azure.com/azurereleasemanager/londonedu-shared/_apis/build/status%2Fbase%2Fbuild-platform-azdo-pipeline?branchName=main)](https://dev.azure.com/azurereleasemanager/londonedu-shared/_build/latest?definitionId=107&branchName=main)

## Pipeline Templates

```shell
ROOT
│   README.md
└─── templates
│    └─── job
│    │    └─── dotnet_build.yml
│    │    └─── dotnet_test.yml
│    │    └─── publish_function.yml
│    │    └─── publish_webapp.yml
│    │    └─── terraform-validate.yml
│    │    └─── terraform-apply.yml
│    │    └─── terraform-apply-to-all-environments.yml
```
- `dotnet_build.yml` this template will build .NET projects and package/publish nuget packages
- `dotnet_test.yml` this template will run .NET functional tests
- `publish_function.yml` this template will publish the function to a function app. It can disable network restrictions when running functional tests
- `publish_webapp.yml` this template will publish the app to a web app. It can also deploy to deployment slots to minimise downtime and can disable network restrictions when running functional tests
- `terraform-validate.yml` this template runs a terraform init and validate against the terraform code
- `terraform-apply.yml` this template runs a terraform init and plan. Also sets Git credentials using the Build Service so terraform modules can be downloaded from a different repository.
- `terraform-apply-to-all-environments.yml` this template follows the path to live process by first deploying to DEV if it is a pull request then once merged to main it deploys to the other environments (SIT, QA, PP, LIVE) using approvals. 

## Scripts
```shell
ROOT
│   README.md
└─── scripts
│    └─── azdo
│    │    └─── Set-VariableGroupFromFiles.ps1
│    │    └─── Set-VariableGroupFromOutputs.ps1
│    └─── terraform
│    │    └─── terraform-fmt-check.sh
```
- `Set-VariableGroupFromFiles.ps1` a powershell script that takes a json file to create/update library group variables.
- `Set-VariableGroupFromOutputs.ps1` a powershell script that takes the terraform output and uses it to create/update library group variables. (NOT BEING USED)
- `terraform-fmt-check.sh` a shell script which checks if the terraform code has been formatted correctly. 

## Using the shared pipeline templates
To use these templates in the pipeline yaml, you need to use the 'resources' tag in your pipeline to pull down the templates and then use the "@" symbol 
when referencing a particular tempate, see below we are pulling the platform-azdo-pipeline repo with tag 0.1.30 and then using the terraform-apply-to-all-environments.yml template:
```
resources:
  repositories:
    - repository: pipeline
      type: git
      name: londonedu-shared/platform-azdo-pipeline
      ref: refs/tags/0.1.30

...
- template: templates/job/terraform-apply-to-all-environments.yml@pipeline
    parameters:
      terraformDirectory: '$(terraformDirectory)'

```

## Creating or updating pipeline templates
You will need to do the following:
- Create a branch
- Make the relevant change e.g. update the templates/job/terraform-apply-to-all-environments.yml file
- Create a PR
- Manually kick off this pipeline, https://dev.azure.com/azurereleasemanager/londonedu-shared/_build?definitionId=107 selecting your branch.
- This will produce a GIT Tag (https://dev.azure.com/azurereleasemanager/londonedu-shared/_git/platform-azdo-pipeline/tags) e.g. 0.1.30-[branch-name] which you can reference in your calling pipeline yaml
- Once you are happy with the change, you can merge your branch into main by completing the pull request
- This will trigger the same pipeline above and produce a new official tag e.g. 0.1.30 which you can reference in your calling pipeline yaml
