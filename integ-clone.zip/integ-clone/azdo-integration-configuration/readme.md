# platform-integration-configuration

This repository contains the terraform code for Azure DevOps.

Terraform is used to create the platform-integration-configuration project, repositories and branch policies. 
