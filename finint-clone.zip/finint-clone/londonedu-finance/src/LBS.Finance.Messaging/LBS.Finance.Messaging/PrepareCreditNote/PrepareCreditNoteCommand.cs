﻿using LBS.Finance.Messaging.PrepareInvoice.V1;
using System.Text.Json.Serialization;

namespace LBS.Finance.Messaging.PrepareCreditNote.V1;

public class PrepareCreditNoteCommand
{
    [JsonPropertyName("crmApplicationId")]
    public Guid? CrmApplicationId { get; set; }

    [JsonPropertyName("lbsNo")]
    public string? LbsNo { get; set; }

    [JsonPropertyName("dateOfBirth")]
    public DateTime? DateOfBirth { get; set; }

    [JsonPropertyName("programmeCode")]
    public string? ProgrammeCode { get; set; }

    [JsonPropertyName("programmeClassification")]
    public string? ProgrammeClassification { get; set; }

    [JsonPropertyName("programmeStudyLocation")]
    public string? ProgrammeStudyLocation { get; set; }

    [JsonPropertyName("sponsor")]
    public Sponsor? Sponsor { get; set; }
}