﻿using System.Text.Json.Serialization;

namespace LBS.Finance.Messaging.PrepareInvoice.V1
{
    public class Discount
    {
        [JsonPropertyName("value")]
        public string? Value { get; set; }

        [JsonPropertyName("reason")]
        public string? Reason { get; set; }
    }
}
