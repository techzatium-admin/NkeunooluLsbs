using System.Text.Json.Serialization;

namespace LBS.Finance.Messaging.PrepareInvoice.V1;

public class Sponsor
{
    [JsonPropertyName("companyName")]
    public string? CompanyName { get; set; }

    [JsonPropertyName("title")]
    public string? Title { get; set; }

    [JsonPropertyName("firstName")]
    public string? FirstName { get; set; }

    [JsonPropertyName("lastName")]
    public string? LastName { get; set; }

    [JsonPropertyName("phoneNumbers")]
    public PhoneNumbers? PhoneNumbers { get; set; }

    [JsonPropertyName("emailAddresses")]
    public EmailAddresses? EmailAddresses { get; set; }

    [JsonPropertyName("address")]
    public Address? Address { get; set; }
}