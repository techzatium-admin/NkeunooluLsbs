﻿using System.Text.Json.Serialization;

namespace LBS.Finance.Messaging.PrepareInvoice.V1;

public class PrepareInvoiceCommand
{
    [JsonPropertyName("crmApplicationId")]
    public Guid? CrmApplicationId { get; set; }

    [JsonPropertyName("title")]
    public string? Title { get; set; }

    [JsonPropertyName("firstName")]
    public string? FirstName { get; set; }

    [JsonPropertyName("lastName")]
    public string? LastName { get; set; }

    [JsonPropertyName("dateOfBirth")]
    public DateTime? DateOfBirth { get; set; }

    [JsonPropertyName("emailAddresses")]
    public EmailAddresses? EmailAddresses { get; set; }

    [JsonPropertyName("lbsNo")]
    public string? LbsNo { get; set; }

    [JsonPropertyName("purchaseOrderNumber")]
    public string? PurchaseOrderNumber { get; set; }

    [JsonPropertyName("phoneNumbers")]
    public PhoneNumbers? PhoneNumbers { get; set; }

    [JsonPropertyName("stage")]
    public string? Stage { get; set; }

    [JsonPropertyName("programme")]
    public Programme? Programme { get; set; }

    [JsonPropertyName("homeAddress")]
    public Address? HomeAddress { get; set; }

    [JsonPropertyName("reservationFee")]
    public Money? ReservationFee { get; set; }

    [JsonPropertyName("commitmentFee")]
    public Money? CommitmentFee { get; set; }

    [JsonPropertyName("reservationFeeDueDate")]
    public DateTime? ReservationFeeDueDate { get; set; }

    [JsonPropertyName("commitmentFeeDueDate")]
    public DateTime? CommitmentFeeDueDate { get; set; }

    [JsonPropertyName("discount")]
    public Discount? Discount { get; set; }

    [JsonPropertyName("sponsor")]
    public Sponsor? Sponsor { get; set; }
    
    [JsonPropertyName("nationalOf")]
    public string? NationalOf { get; set; }

    [JsonPropertyName("applicantCompanyName")]
    public string? ApplicantCompanyName { get; set; }
}