using System.Text.Json.Serialization;

namespace LBS.Finance.Messaging.PrepareInvoice.V1;

public class Programme
{
    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("type")]
    public string? Type { get; set; }

    [JsonPropertyName("start")]
    public DateTime? Start { get; set; }

    [JsonPropertyName("end")]
    public DateTime? End { get; set; }

    [JsonPropertyName("duration")]
    public string? Duration { get; set; }

    [JsonPropertyName("fee")]
    public Money? Fee { get; set; }

    [JsonPropertyName("studyLocation")]
    public string? StudyLocation { get; set; }

    [JsonPropertyName("classification")]
    public string? Classification { get; set; }
    
    [JsonPropertyName("studyMethod")]
    public string? StudyMethod { get; set; }
}