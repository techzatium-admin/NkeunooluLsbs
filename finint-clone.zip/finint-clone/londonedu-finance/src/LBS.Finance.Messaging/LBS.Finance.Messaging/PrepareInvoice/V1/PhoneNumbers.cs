using System.Text.Json.Serialization;

namespace LBS.Finance.Messaging.PrepareInvoice.V1;

public class PhoneNumbers
{
    [JsonPropertyName("preferredContactNumber")]
    public string? PreferredContactNumber { get; set; }
    
    [JsonPropertyName("home")]
    public string? Home { get; set; }

    [JsonPropertyName("work")]
    public string? Work { get; set; }

    [JsonPropertyName("homeMobile")]
    public string? HomeMobile { get; set; }

    [JsonPropertyName("workMobile")]
    public string? WorkMobile { get; set; }
}