using System.Text.Json.Serialization;

namespace LBS.Finance.Messaging.PrepareInvoice.V1;

public class Money
{
    [JsonPropertyName("currency")]
    public string? Currency { get; set; }

    [JsonPropertyName("value")]
    public string? Value { get; set; }
}