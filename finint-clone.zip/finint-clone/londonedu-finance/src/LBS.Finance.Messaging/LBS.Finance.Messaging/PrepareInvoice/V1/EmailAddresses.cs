using System.Text.Json.Serialization;

namespace LBS.Finance.Messaging.PrepareInvoice.V1;

public class EmailAddresses
{
    [JsonPropertyName("preferredEmail")]
    public string? PreferredEmail { get; set; }

    [JsonPropertyName("personalEmail1")]
    public string? PersonalEmail1 { get; set; }

    [JsonPropertyName("personalEmail2")]
    public string? PersonalEmail2 { get; set; }

    [JsonPropertyName("workEmail1")]
    public string? WorkEmail1 { get; set; }

    [JsonPropertyName("workEmail2")]
    public string? WorkEmail2 { get; set; }

    [JsonPropertyName("schoolEmail")]
    public string? SchoolEmail { get; set; }

    [JsonPropertyName("otherEmail")]
    public string? OtherEmail{ get; set; }
}