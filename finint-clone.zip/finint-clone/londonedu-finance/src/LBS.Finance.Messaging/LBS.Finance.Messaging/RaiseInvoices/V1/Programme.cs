using System.Text.Json.Serialization;

namespace LBS.Finance.Messaging.RaiseInvoices.V1;

public class Programme
{
    [JsonPropertyName("type")]
    public string? Type { get; set; }
    
    [JsonPropertyName("code")]
    public string? Code { get; set; }
    
    [JsonPropertyName("yearGroup")]
    public string? YearGroup { get; set; }
}