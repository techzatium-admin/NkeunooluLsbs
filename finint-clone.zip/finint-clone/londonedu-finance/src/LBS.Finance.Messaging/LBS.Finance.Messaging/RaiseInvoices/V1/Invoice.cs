using System.Text.Json.Serialization;

namespace LBS.Finance.Messaging.RaiseInvoices.V1;

public class Invoice
{
    [JsonPropertyName("crmApplicationId")]
    public Guid? CrmApplicationId { get; set; }
    
    [JsonPropertyName("processingYear")]
    public int? ProcessingYear { get; set; }
    
    [JsonPropertyName("processingPeriod")]
    public int? ProcessingPeriod { get; set; }
    
    [JsonPropertyName("invoiceDate")]
    public DateTime? InvoiceDate { get; set; }
    
    [JsonPropertyName("dueDate")]
    public DateTime? DueDate { get; set; }
    
    [JsonPropertyName("finalPaymentDate")]
    public DateTime? FinalPaymentDate { get; set; }
    
    [JsonPropertyName("technologyOneDebtorId")]
    public string? TechnologyOneDebtorId { get; set; }
    
    [JsonPropertyName("technologyOneSponsorId")]
    public string? TechnologyOneSponsorId { get; set; }
    
    [JsonPropertyName("lbsNo")]
    public string? LbsNo { get; set; }
    
    [JsonPropertyName("amount")]
    public Amount? Amount { get; set; }
    
    [JsonPropertyName("invoiceType")]
    public string? InvoiceType { get; set; }
    
    [JsonPropertyName("entityName")]
    public string? EntityName { get; set; }
    
    [JsonPropertyName("purchaseOrderNumber")]
    public string? PurchaseOrderNumber { get; set; }

    [JsonPropertyName("stage")]
    public string? Stage { get; set; }

    [JsonPropertyName("department")]
    public string? Department { get; set; }
    
    [JsonPropertyName("programme")]
    public Programme? Programme { get; set; }

    [JsonPropertyName("recognition")]
    public Recognition? Recognition { get; set; }

    [JsonPropertyName("discount")]
    public Discount? Discount { get; set;}

    [JsonPropertyName("participantName")]
    public string? ParticipantName { get; set; }
}