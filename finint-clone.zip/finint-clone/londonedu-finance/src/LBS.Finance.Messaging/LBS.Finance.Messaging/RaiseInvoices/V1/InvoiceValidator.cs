using FluentValidation;

namespace LBS.Finance.Messaging.RaiseInvoices.V1;

public class InvoiceValidator: AbstractValidator<Invoice>
{
    private const string UuidRegex = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$";

    public InvoiceValidator()
    {
        RuleFor(x => x.CrmApplicationId.ToString())
            .Matches(UuidRegex)
            .NotEmpty();

        RuleFor(x => x.InvoiceDate).NotNull().NotEmpty();
        RuleFor(x => x.ProcessingYear).GreaterThan(0);
        RuleFor(x => x.DueDate).NotNull().NotEmpty();
        RuleFor(x => x.FinalPaymentDate).NotNull().NotEmpty();
        RuleFor(x => x.TechnologyOneDebtorId).NotNull().NotEmpty();
        RuleFor(x => x.LbsNo).NotNull().NotEmpty();
        RuleFor(x => x.Amount).NotNull().NotEmpty();
        RuleFor(x => x.InvoiceType).NotNull().NotEmpty();
        RuleFor(x => x.EntityName).NotNull().NotEmpty();
        RuleFor(x => x.Department).NotNull().NotEmpty();
        RuleFor(x => x.Programme).NotNull().NotEmpty();
    }
}