using System.Text.Json.Serialization;

namespace LBS.Finance.Messaging.RaiseInvoices.V1;

public class RaiseInvoicesCommand
{
    [JsonPropertyName("invoices")]
    public IEnumerable<Invoice>? Invoices { get; set; }
}