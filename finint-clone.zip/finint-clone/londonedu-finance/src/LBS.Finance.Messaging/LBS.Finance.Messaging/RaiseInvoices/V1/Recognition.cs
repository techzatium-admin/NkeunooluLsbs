using System.Text.Json.Serialization;

namespace LBS.Finance.Messaging.RaiseInvoices.V1;

public class Recognition
{
    [JsonPropertyName("periodCount")]
    public int? PeriodCount { get; set; }

    [JsonPropertyName("startDate")]
    public string? StartDate { get; set; }
}