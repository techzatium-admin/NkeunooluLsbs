using System.Text.Json.Serialization;

namespace LBS.Finance.Messaging.OfferAccepted.V1;

public class OfferAcceptedEvent
{
    [JsonPropertyName("contactId")]
    public Guid ContactId { get; set; }
    
    [JsonPropertyName("applicationId")]
    public Guid ApplicationId { get; set; }

    [JsonPropertyName("commandType")]
    public string? CommandType { get; set; }
}