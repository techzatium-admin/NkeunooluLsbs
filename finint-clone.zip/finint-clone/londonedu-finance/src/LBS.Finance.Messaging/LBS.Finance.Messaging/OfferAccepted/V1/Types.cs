﻿namespace LBS.Finance.Messaging;

public enum CommandType
{
    Invoice = 'I',
    CreditNote = 'C'
}
