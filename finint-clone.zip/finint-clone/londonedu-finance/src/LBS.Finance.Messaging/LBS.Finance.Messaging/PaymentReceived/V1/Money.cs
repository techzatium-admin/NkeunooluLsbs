﻿using System.Text.Json.Serialization;

namespace LBS.Finance.Messaging.PaymentReceived.V1;

/// <summary>
/// Model for the amount of transactions from Technology One.
/// </summary>
public class Money
{
    /// <summary>
    /// Currency the transaction was made in.
    /// </summary>
    [JsonPropertyName("currency")]
    public string? Currency { get; set; }

    /// <summary>
    /// Currency the transaction was made in.
    /// </summary>
    [JsonPropertyName("value")]
    public string? Value { get; set; }
}