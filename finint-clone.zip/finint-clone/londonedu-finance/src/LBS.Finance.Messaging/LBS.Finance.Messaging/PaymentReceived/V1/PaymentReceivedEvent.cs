﻿using System.Text.Json.Serialization;

namespace LBS.Finance.Messaging.PaymentReceived.V1;

/// <summary>
/// Model for transactions from Technology One.
/// </summary>
public class PaymentReceivedEvent
{
    /// <summary>
    /// Unique identifier for the students application.
    /// </summary>
    [JsonPropertyName("crmApplicationId")]
    public Guid? ApplicationId { get; set; }

    /// <summary>
    /// LBS Number.  The common identifier across systems for a student.
    /// </summary>
    [JsonPropertyName("lbsNumber")]
    public string? LbsNumber { get; set; }

    /// <summary>
    /// The kind of fee this transaction is for.
    /// </summary>
    [JsonPropertyName("invoiceType")]
    public string? InvoiceType { get; set; }

    /// <summary>
    /// Transaction identifier.
    /// </summary>
    [JsonPropertyName("transactionId")]
    public string? TransactionId { get; set; }

    /// <summary>
    /// Amount the transaction was for.
    /// </summary>
    [JsonPropertyName("transactionDateTime")]
    public DateTimeOffset? TransactionDateTime { get; set; }

    /// <summary>
    /// The payment method which was used for this transaction.
    /// </summary>
    [JsonPropertyName("paymentMethod")]
    public string? PaymentMethod { get; set; }

    /// <summary>
    /// Merchant Reference for this transaction.
    /// </summary>
    [JsonPropertyName("merchantReference")]
    public string? MerchantReference { get; set; }

    /// <summary>
    /// The amount the transaction was for.
    /// </summary>
    [JsonPropertyName("amount")]
    public Money? Amount { get; set; }

    [JsonPropertyName("totalFeesPaid")]
    public Money? TotalFeesPaid { get; set; }

    [JsonPropertyName("programmeCode")]
    public string? ProgrammeCode { get; set; }
}