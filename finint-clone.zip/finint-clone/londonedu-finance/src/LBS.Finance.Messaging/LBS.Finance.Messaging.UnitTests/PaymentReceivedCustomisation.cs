﻿using AutoFixture;
using LBS.Finance.Messaging.PaymentReceived.V1;

namespace LBS.Finance.Messaging.UnitTests;

public class PaymentReceivedCustomisation : ICustomization
{
    public void Customize(IFixture fixture)
    {
        fixture.Customize<PaymentReceivedEvent>(composer => composer
            .With(x => x.InvoiceType, GenerateInvoiceType())
            .With(x => x.PaymentMethod, GeneratePaymentMethod())
            .WithAutoProperties()
        );
    }

    private static string GeneratePaymentMethod() => RandomGenerator.Random.Next(1, 2) switch
    {
        1 => "Card",
        2 => "BankTransfer",
        _ => "BankTransfer"
    };

    private static string GenerateInvoiceType() => RandomGenerator.Random.Next(1, 3) switch
    {
        1 => "CommitmentFee",
        2 => "ReservationFee",
        3 => "ProgrammeFee",
        _ => "ProgrammeFee"
    };
}