﻿using LBS.Finance.Messaging.PrepareInvoice.V1;

namespace LBS.Finance.Messaging.UnitTests.PrepareInvoice.V1;

public class PrepareInvoiceJsonSchemaValidationTests : JsonSchemaValidationTests<PrepareInvoiceCommand>
{
    public override string SchemaFilePath => "PrepareInvoice/V1/prepare-invoice-v1-schema.json";
}

