using System.Globalization;
using AutoFixture;
using LBS.Finance.Messaging.RaiseInvoices.V1;

namespace LBS.Finance.Messaging.UnitTests;

public class DiscountCustomisation : ICustomization
{
    public void Customize(IFixture fixture)
    {
        fixture.Customize<Discount>(composer => composer
            .With(x => x.Value, fixture.Create<decimal>().ToString(CultureInfo.InvariantCulture))
            .With(x => x.Reason, fixture.Create<bool>() ? "Staff" : "Other"));
    }
}