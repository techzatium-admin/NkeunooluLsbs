using AutoFixture;
using AutoFixture.AutoNSubstitute;
using AutoFixture.NUnit3;
using LBS.Finance.Messaging.UnitTests.PrepareInvoice;

namespace LBS.Finance.Messaging.UnitTests;

public class AutoNSubstituteDataAttribute : AutoDataAttribute
{
    public AutoNSubstituteDataAttribute()
        : this(() => new Fixture())
    {
    }

    protected AutoNSubstituteDataAttribute(Func<IFixture> fixtureFactory)
        : base(() => CreateFixture(fixtureFactory()))
    {
    }

    public static IFixture CreateFixture(IFixture fixture)
    {
        CreateOmitOnRecursionFixture(fixture);
        return fixture;
    }

    private static void CreateOmitOnRecursionFixture(IFixture fixture)
    {
        fixture.Customize(new AutoNSubstituteCustomization());
        fixture.Customize(new MoneyCustomisation());
        fixture.Customize(new DiscountCustomisation());
        fixture.Customize(new PaymentReceivedCustomisation());
        fixture.Behaviors.OfType<ThrowingRecursionBehavior>().ToList()
            .ForEach(b => fixture.Behaviors.Remove(b));
        fixture.Behaviors.Add(new OmitOnRecursionBehavior(5));
    }
}