﻿namespace LBS.Finance.Messaging.UnitTests;

public static class RandomGenerator
{
    public static Random Random { get; } = new Random();
}