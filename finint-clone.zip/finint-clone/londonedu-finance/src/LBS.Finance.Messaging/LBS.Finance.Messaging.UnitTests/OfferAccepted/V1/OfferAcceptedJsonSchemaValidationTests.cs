﻿using LBS.Finance.Messaging.OfferAccepted.V1;

namespace LBS.Finance.Messaging.UnitTests.OfferAccepted.V1;

public class OfferAcceptedJsonSchemaValidationTests : JsonSchemaValidationTests<OfferAcceptedEvent>
{
    public override string SchemaFilePath => "OfferAccepted/V1/offer-accepted-v1-schema.json";
}