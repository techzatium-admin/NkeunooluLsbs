using Shouldly;
using NUnit.Framework;

namespace LBS.Finance.Messaging.UnitTests;

public abstract class JsonSchemaValidationTests<T>
    where T : class
{
    public abstract string SchemaFilePath { get; }

    [Theory]
    [AutoNSubstituteData]
    public async Task GivenEvent_WhenICheckItsValidAgainstTheJsonSchema_ThenItsSuccess(T @event)
    {
        // Arrange
        var json = System.Text.Json.JsonSerializer.Serialize(@event);
        var jsonNode = System.Text.Json.Nodes.JsonNode.Parse(json);
        var schemaPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, SchemaFilePath);
        var schemaJson = await File.ReadAllTextAsync(schemaPath);

        // Use JsonSchema.Net for validation
        var schema = Json.Schema.JsonSchema.FromText(schemaJson);

        var result = schema.Evaluate(jsonNode, new Json.Schema.EvaluationOptions { OutputFormat = Json.Schema.OutputFormat.List });

        // Assert
        //result.IsValid.ShouldBeTrue(); Does not work for all tests, Errors is null but invalid
        result.Errors.ShouldBeNull();
    }
}