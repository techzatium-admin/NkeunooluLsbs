using System.Globalization;
using AutoFixture;
using LBS.Finance.Messaging.PrepareInvoice.V1;

namespace LBS.Finance.Messaging.UnitTests;

public class MoneyCustomisation : ICustomization
{
    public void Customize(IFixture fixture)
    {
        fixture.Customize<LBS.Finance.Messaging.PrepareInvoice.V1.Money>(composer => composer
            .With(x => x.Value, fixture.Create<decimal>().ToString(CultureInfo.InvariantCulture))
            .With(x => x.Currency, fixture.Create<bool>() ? "GBP" : "USD"));
        fixture.Customize<LBS.Finance.Messaging.PaymentReceived.V1.Money>(composer => composer
            .With(x => x.Value, fixture.Create<decimal>().ToString(CultureInfo.InvariantCulture))
            .With(x => x.Currency, fixture.Create<bool>() ? "GBP" : "USD"));
    }
}