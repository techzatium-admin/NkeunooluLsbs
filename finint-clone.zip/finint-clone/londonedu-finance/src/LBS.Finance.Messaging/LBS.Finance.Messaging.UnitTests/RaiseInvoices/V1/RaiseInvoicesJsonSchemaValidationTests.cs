using LBS.Finance.Messaging.RaiseInvoices.V1;

namespace LBS.Finance.Messaging.UnitTests.RaiseInvoices.V1;

public class RaiseInvoicesJsonSchemaValidationTests : JsonSchemaValidationTests<RaiseInvoicesCommand>
{
    public override string SchemaFilePath => "RaiseInvoices/V1/raise-invoices-v1-schema.json";
}
