﻿using LBS.Finance.Messaging.PaymentReceived.V1;

namespace LBS.Finance.Messaging.UnitTests.PaymentReceived.V1;

public class PaymentReceivedInvoiceJsonSchemaValidationTests : JsonSchemaValidationTests<PaymentReceivedEvent>
{
    public override string SchemaFilePath => "PaymentReceived/V1/payment-received-v1-schema.json";
}