﻿using LBS.Finance.Common.Extensions;
using NUnit.Framework;
using Shouldly;

namespace LBS.Finance.Common.UnitTests.Extensions
{
    public class StringExtensionsTests
    {
        [Test]
        public void GetOrCreateCorrelationId_GivenCorrelationId_ShouldReturnCorrelationId()
        {
            var correlationId = Guid.NewGuid().ToString();

            var result = correlationId.GetOrCreateCorrelationId();

            result.ShouldBe(correlationId);
        }

        [Theory]
        [TestCase("")]
        [TestCase(" ")]
        [TestCase(null)]
        public void GetOrCreateCorrelationId_GivenEmpty(string? correlationId)
        {
            var result = correlationId.GetOrCreateCorrelationId();

            IsValidGuid(result).ShouldBeTrue();
        }

        private bool IsValidGuid(string value)
        {
            return Guid.TryParse(value, out _);
        }
    }
}
