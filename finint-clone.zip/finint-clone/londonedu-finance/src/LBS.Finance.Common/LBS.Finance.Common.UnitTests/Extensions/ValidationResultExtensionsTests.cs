﻿using FluentValidation.Results;
using LBS.Finance.Common.Extensions;
using NUnit.Framework;
using Shouldly;

namespace LBS.Finance.Common.UnitTests.Extensions;

public class ValidationResultExtensionsTests
{
    [Test]
    public void GenerateValidationErrorMessage_WhenValid_ShouldBeEmpty()
    {
        var validationResult = new ValidationResult();

        var result = validationResult.GenerateValidationErrorMessage();

        result.ShouldBeEmpty();
    }

    [Test]
    public void GenerateValidationErrorMessage_AnInvalidValue_ShouldProvideDetailedMessage()
    {
        var validationFailure = new ValidationFailure("PropertyName", "InvalidName", null)
        {
            ErrorCode = "errorCode"
        };
        var validationResult = new ValidationResult(new[] { validationFailure });

        var result = validationResult.GenerateValidationErrorMessage();

        result.ShouldContain("PropertyName");
        result.ShouldContain("errorCode");
        result.ShouldContain("InvalidName");
        result.ShouldContain("null");
    }

    [Test]
    public void GenerateValidationErrorMessage_MultipleInvalidValue_ShouldProvideDetailedMessage()
    {
        var validationFailure1 = new ValidationFailure("PropertyName1", "InvalidName1", "one")
        {
            ErrorCode = "errorCode1"
        };
        var validationFailure2 = new ValidationFailure("PropertyName2", "InvalidName2", "two")
        {
            ErrorCode = "errorCode2"
        };
        var validationResult = new ValidationResult(new[] { validationFailure1, validationFailure2 });

        var result = validationResult.GenerateValidationErrorMessage();

        result.ShouldContain("PropertyName1");
        result.ShouldContain("errorCode1");
        result.ShouldContain("InvalidName1");
        result.ShouldContain("one");

        result.ShouldContain("PropertyName2");
        result.ShouldContain("errorCode2");
        result.ShouldContain("InvalidName2");
        result.ShouldContain("two");
    }
}