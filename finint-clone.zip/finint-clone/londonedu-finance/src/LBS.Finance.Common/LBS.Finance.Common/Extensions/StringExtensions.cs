﻿namespace LBS.Finance.Common.Extensions
{
    public static class StringExtensions
    {
        public static string GetOrCreateCorrelationId(this string correlationId)
        {
            return string.IsNullOrWhiteSpace(correlationId)
            ? Guid.NewGuid().ToString()
                : correlationId;
        }
    }
}
