﻿using FluentValidation.Results;

namespace LBS.Finance.Common.Extensions;

public static class ValidationResultExtensions
{
    public static string GenerateValidationErrorMessage(this ValidationResult validationResult)
    {
        return validationResult.IsValid
            ? string.Empty
            : string.Join(',',
                validationResult.Errors.Select(i =>
                    $"ErrorCode: '{i.ErrorCode}' ErrorMessage: '{i.ErrorMessage}' PropertyName: '{i.PropertyName}' Value: '{i.AttemptedValue ?? "null"}'"));
    }
}