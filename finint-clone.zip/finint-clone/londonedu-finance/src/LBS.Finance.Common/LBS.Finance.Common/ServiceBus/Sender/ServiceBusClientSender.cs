﻿using Azure.Identity;
using Azure.Messaging.ServiceBus;
using System.Text.Json;

namespace LBS.Finance.Common.ServiceBus.Sender
{
    public class ServiceBusClientSender : IServiceBusClientSender
    {
        public async Task SendAsync(ServiceBusClientSenderMessage message)
        {
            await using var client = new ServiceBusClient(message.FullyQualifiedNamespace, new DefaultAzureCredential());
            var sender = client.CreateSender(message.QueueOrTopicName);

            var serviceBusMessage = new ServiceBusMessage(JsonSerializer.Serialize(message.Body, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase }))
            {
                ApplicationProperties =
                {
                    { "CommandType", message.CommandType ?? string.Empty }
                },
                CorrelationId = message.CorrelationId
            };

            await sender.SendMessageAsync(serviceBusMessage, message.CancellationToken);
        }
    }
}
