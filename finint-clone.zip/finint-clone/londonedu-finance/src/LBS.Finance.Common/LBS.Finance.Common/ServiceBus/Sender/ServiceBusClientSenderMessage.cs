﻿using System.Data;

namespace LBS.Finance.Common.ServiceBus.Sender
{
    public class ServiceBusClientSenderMessage
    {
        public object Body { get; }
        public string FullyQualifiedNamespace { get; }
        public string QueueOrTopicName { get; }
        public string? CorrelationId { get; }
        public string? CommandType { get; set; }
        public CancellationToken CancellationToken { get; }

        public ServiceBusClientSenderMessage(object body, string fullyQualifiedNamespace, string queueOrTopicName, string? correlationId = null, CancellationToken cancellationToken = default, string? commandType = null)
        {
            Body = body;
            FullyQualifiedNamespace = fullyQualifiedNamespace;
            QueueOrTopicName = queueOrTopicName;
            CorrelationId = correlationId;
            CommandType = commandType;
            CancellationToken = cancellationToken;
        }
    }
}
