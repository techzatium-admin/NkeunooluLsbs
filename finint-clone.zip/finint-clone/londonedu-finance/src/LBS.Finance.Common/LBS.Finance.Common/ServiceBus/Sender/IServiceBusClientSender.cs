﻿namespace LBS.Finance.Common.ServiceBus.Sender
{
    public interface IServiceBusClientSender
    {
        Task SendAsync(ServiceBusClientSenderMessage message);
    }
}
